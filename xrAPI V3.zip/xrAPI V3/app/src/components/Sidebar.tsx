import { 
  LayoutDashboard, 
  ScanLine, 
  Search, 
  History, 
  Shield,
  Activity,
  Wifi,
  WifiOff
} from 'lucide-react'
import { cn } from '@/lib/utils'
import type { View } from '../App'

interface SidebarProps {
  currentView: View
  onViewChange: (view: View) => void
  isConnected: boolean
}

const navItems: { id: View; label: string; icon: React.ElementType }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'scan', label: 'New Scan', icon: ScanLine },
  { id: 'results', label: 'Results Explorer', icon: Search },
  { id: 'changelog', label: 'Changelog', icon: History },
]

export function Sidebar({ currentView, onViewChange, isConnected }: SidebarProps) {
  return (
    <aside className="w-64 bg-sidebar border-r border-sidebar-border flex flex-col">
      {/* Logo */}
      <div className="p-6 border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
            <Shield className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gradient">xrAPI</h1>
            <p className="text-xs text-muted-foreground">API Security Scanner</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <ul className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon
            const isActive = currentView === item.id
            
            return (
              <li key={item.id}>
                <button
                  onClick={() => onViewChange(item.id)}
                  className={cn(
                    'w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200',
                    isActive
                      ? 'bg-sidebar-primary/20 text-sidebar-primary'
                      : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                  )}
                >
                  <Icon className={cn('w-5 h-5', isActive && 'text-primary')} />
                  {item.label}
                  {isActive && (
                    <div className="ml-auto w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
                  )}
                </button>
              </li>
            )
          })}
        </ul>
      </nav>

      {/* Status */}
      <div className="p-4 border-t border-sidebar-border">
        <div className="space-y-3">
          {/* Connection Status */}
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground flex items-center gap-2">
              <Activity className="w-3.5 h-3.5" />
              API Status
            </span>
            <span className={cn(
              'flex items-center gap-1.5',
              isConnected ? 'text-green-400' : 'text-red-400'
            )}>
              {isConnected ? (
                <>
                  <Wifi className="w-3.5 h-3.5" />
                  Connected
                </>
              ) : (
                <>
                  <WifiOff className="w-3.5 h-3.5" />
                  Offline
                </>
              )}
            </span>
          </div>
          
          {/* Version */}
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Version</span>
            <span className="font-mono">v1.0.0</span>
          </div>
        </div>
      </div>
    </aside>
  )
}
