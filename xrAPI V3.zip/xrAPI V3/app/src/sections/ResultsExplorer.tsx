import { useState } from 'react'
import { 
  Search, 
  Filter, 
  FileJson,
  FileCode,
  FileSpreadsheet,
  ChevronRight, 
  ChevronDown,
  Shield,
  CheckCircle,
  Clock,
  Activity
} from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Separator } from '@/components/ui/separator'
import { toast } from 'sonner'

// Mock data
const mockScans = [
  { id: 'scan-1', name: 'Production API Scan', target: 'https://api.example.com', date: '2024-01-15', status: 'completed', endpoints: 156 },
  { id: 'scan-2', name: 'Staging API Scan', target: 'https://staging.api.example.com', date: '2024-01-14', status: 'completed', endpoints: 142 },
  { id: 'scan-3', name: 'Dev API Scan', target: 'https://dev.api.example.com', date: '2024-01-13', status: 'completed', endpoints: 89 },
]

const mockClusters = [
  {
    id: 'c1',
    pattern: '/api/v1/users/{id}',
    risk: 'authenticated',
    confidence: 0.95,
    observed: 47,
    samples: ['1', '2', '3', '123', '456'],
    avgResponseTime: 45,
  },
  {
    id: 'c2',
    pattern: '/api/v1/products/{id}',
    risk: 'public',
    confidence: 0.92,
    observed: 128,
    samples: ['1', '2', 'prod-123', 'abc-456'],
    avgResponseTime: 32,
  },
  {
    id: 'c3',
    pattern: '/api/v1/admin/{resource}',
    risk: 'privileged',
    confidence: 0.88,
    observed: 12,
    samples: ['users', 'settings', 'logs'],
    avgResponseTime: 78,
  },
  {
    id: 'c4',
    pattern: '/api/internal/{path}',
    risk: 'sensitive',
    confidence: 0.85,
    observed: 8,
    samples: ['config', 'health', 'metrics'],
    avgResponseTime: 23,
  },
  {
    id: 'c5',
    pattern: '/api/v1/auth/{action}',
    risk: 'public',
    confidence: 0.90,
    observed: 5,
    samples: ['login', 'logout', 'refresh'],
    avgResponseTime: 156,
  },
]

const mockTransactions = [
  { id: 't1', method: 'GET', path: '/api/v1/users/1', status: 200, time: 45, size: 2048, timestamp: '2024-01-15T10:30:00Z' },
  { id: 't2', method: 'GET', path: '/api/v1/users/2', status: 200, time: 42, size: 1892, timestamp: '2024-01-15T10:30:01Z' },
  { id: 't3', method: 'POST', path: '/api/v1/auth/login', status: 401, time: 156, size: 128, timestamp: '2024-01-15T10:30:05Z' },
  { id: 't4', method: 'GET', path: '/api/internal/config', status: 403, time: 12, size: 64, timestamp: '2024-01-15T10:30:08Z' },
  { id: 't5', method: 'GET', path: '/api/v1/admin/users', status: 200, time: 89, size: 8192, timestamp: '2024-01-15T10:30:12Z' },
  { id: 't6', method: 'GET', path: '/api/v1/products/123', status: 200, time: 28, size: 1536, timestamp: '2024-01-15T10:30:15Z' },
  { id: 't7', method: 'PUT', path: '/api/v1/users/1', status: 200, time: 67, size: 512, timestamp: '2024-01-15T10:30:20Z' },
  { id: 't8', method: 'DELETE', path: '/api/v1/users/2', status: 204, time: 34, size: 0, timestamp: '2024-01-15T10:30:25Z' },
]

function RiskBadge({ risk }: { risk: string }) {
  const className = `badge-${risk}`
  return <span className={className}>{risk}</span>
}

function MethodBadge({ method }: { method: string }) {
  const className = `method-${method.toLowerCase()}`
  return <span className={className}>{method}</span>
}

function StatusBadge({ status }: { status: number }) {
  let className = 'status-'
  if (status >= 200 && status < 300) className += '2xx'
  else if (status >= 300 && status < 400) className += '3xx'
  else if (status >= 400 && status < 500) className += '4xx'
  else className += '5xx'
  
  return <span className={className}>{status}</span>
}

function ClusterNode({ cluster, isExpanded, onToggle }: { 
  cluster: typeof mockClusters[0]
  isExpanded: boolean
  onToggle: () => void 
}) {
  return (
    <div className="border border-border rounded-lg overflow-hidden">
      <div 
        className="flex items-center justify-between p-4 bg-muted/30 cursor-pointer hover:bg-muted/50 transition-colors"
        onClick={onToggle}
      >
        <div className="flex items-center gap-3">
          {isExpanded ? (
            <ChevronDown className="w-5 h-5 text-muted-foreground" />
          ) : (
            <ChevronRight className="w-5 h-5 text-muted-foreground" />
          )}
          <div>
            <div className="font-mono text-sm font-medium">{cluster.pattern}</div>
            <div className="text-xs text-muted-foreground mt-0.5">
              {cluster.observed} observed paths
            </div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <RiskBadge risk={cluster.risk} />
          <div className="text-right">
            <div className="text-xs font-medium">{cluster.confidence.toFixed(0)}%</div>
            <div className="text-xs text-muted-foreground">confidence</div>
          </div>
        </div>
      </div>
      
      {isExpanded && (
        <div className="p-4 border-t border-border bg-background/50">
          <div className="space-y-4">
            <div>
              <div className="text-xs font-medium text-muted-foreground mb-2">Parameter Samples</div>
              <div className="flex flex-wrap gap-2">
                {cluster.samples.map((sample, i) => (
                  <code key={i} className="px-2 py-1 bg-muted rounded text-xs font-mono">
                    {sample}
                  </code>
                ))}
              </div>
            </div>
            
            <div className="grid grid-cols-3 gap-4">
              <div className="p-3 bg-muted/30 rounded-lg">
                <div className="text-2xl font-bold">{cluster.observed}</div>
                <div className="text-xs text-muted-foreground">Observed Paths</div>
              </div>
              <div className="p-3 bg-muted/30 rounded-lg">
                <div className="text-2xl font-bold">{cluster.avgResponseTime}ms</div>
                <div className="text-xs text-muted-foreground">Avg Response</div>
              </div>
              <div className="p-3 bg-muted/30 rounded-lg">
                <div className="text-2xl font-bold">{cluster.confidence.toFixed(0)}%</div>
                <div className="text-xs text-muted-foreground">Confidence</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export function ResultsExplorer() {
  const [selectedScan, setSelectedScan] = useState(mockScans[0].id)
  const [searchQuery, setSearchQuery] = useState('')
  const [riskFilter, setRiskFilter] = useState('all')
  const [expandedClusters, setExpandedClusters] = useState<string[]>(['c1'])
  const [activeTab, setActiveTab] = useState('clusters')

  const toggleCluster = (id: string) => {
    setExpandedClusters(prev => 
      prev.includes(id) 
        ? prev.filter(c => c !== id)
        : [...prev, id]
    )
  }

  const filteredClusters = mockClusters.filter(cluster => {
    const matchesSearch = cluster.pattern.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesRisk = riskFilter === 'all' || cluster.risk === riskFilter
    return matchesSearch && matchesRisk
  })

  const filteredTransactions = mockTransactions.filter(tx => 
    tx.path.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const handleExport = (format: string) => {
    toast.success(`Exported results as ${format.toUpperCase()}`)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Results Explorer</h1>
          <p className="text-muted-foreground">Browse discovered endpoints and clusters</p>
        </div>
        
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => handleExport('json')}>
            <FileJson className="w-4 h-4 mr-2" />
            JSON
          </Button>
          <Button variant="outline" size="sm" onClick={() => handleExport('csv')}>
            <FileSpreadsheet className="w-4 h-4 mr-2" />
            CSV
          </Button>
          <Button variant="outline" size="sm" onClick={() => handleExport('openapi')}>
            <FileCode className="w-4 h-4 mr-2" />
            OpenAPI
          </Button>
        </div>
      </div>

      {/* Scan Selector */}
      <Card className="xrapi-card">
        <CardContent className="p-4">
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <label className="text-xs text-muted-foreground mb-1 block">Select Scan</label>
              <Select value={selectedScan} onValueChange={setSelectedScan}>
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {mockScans.map(scan => (
                    <SelectItem key={scan.id} value={scan.id}>
                      <div className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-400" />
                        <span>{scan.name}</span>
                        <span className="text-muted-foreground">- {scan.target}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center gap-4 text-sm">
              <div className="text-center">
                <div className="font-bold">{mockScans.find(s => s.id === selectedScan)?.endpoints}</div>
                <div className="text-xs text-muted-foreground">Endpoints</div>
              </div>
              <Separator orientation="vertical" className="h-8" />
              <div className="text-center">
                <div className="font-bold">{mockClusters.length}</div>
                <div className="text-xs text-muted-foreground">Clusters</div>
              </div>
              <Separator orientation="vertical" className="h-8" />
              <div className="text-center">
                <div className="font-bold">{mockTransactions.length}</div>
                <div className="text-xs text-muted-foreground">Transactions</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Search and Filter */}
      <div className="flex items-center gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search endpoints, paths, or patterns..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        
        <Select value={riskFilter} onValueChange={setRiskFilter}>
          <SelectTrigger className="w-40">
            <Filter className="w-4 h-4 mr-2" />
            <SelectValue placeholder="Risk Level" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Risks</SelectItem>
            <SelectItem value="public">Public</SelectItem>
            <SelectItem value="authenticated">Authenticated</SelectItem>
            <SelectItem value="privileged">Privileged</SelectItem>
            <SelectItem value="sensitive">Sensitive</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="clusters" className="gap-2">
            <Shield className="w-4 h-4" />
            Clusters
          </TabsTrigger>
          <TabsTrigger value="transactions" className="gap-2">
            <Activity className="w-4 h-4" />
            Transactions
          </TabsTrigger>
          <TabsTrigger value="timeline" className="gap-2">
            <Clock className="w-4 h-4" />
            Timeline
          </TabsTrigger>
        </TabsList>

        <TabsContent value="clusters" className="space-y-4">
          <div className="space-y-3">
            {filteredClusters.map(cluster => (
              <ClusterNode
                key={cluster.id}
                cluster={cluster}
                isExpanded={expandedClusters.includes(cluster.id)}
                onToggle={() => toggleCluster(cluster.id)}
              />
            ))}
          </div>
          
          {filteredClusters.length === 0 && (
            <div className="text-center py-12">
              <Search className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No clusters found matching your criteria</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="transactions">
          <Card className="xrapi-card">
            <CardContent className="p-0">
              <table className="data-grid">
                <thead>
                  <tr>
                    <th>Method</th>
                    <th>Path</th>
                    <th>Status</th>
                    <th>Time</th>
                    <th>Size</th>
                    <th>Timestamp</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredTransactions.map(tx => (
                    <tr key={tx.id}>
                      <td><MethodBadge method={tx.method} /></td>
                      <td className="font-mono text-xs">{tx.path}</td>
                      <td><StatusBadge status={tx.status} /></td>
                      <td>{tx.time}ms</td>
                      <td>{(tx.size / 1024).toFixed(1)}KB</td>
                      <td className="text-muted-foreground">
                        {new Date(tx.timestamp).toLocaleTimeString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="timeline">
          <Card className="xrapi-card">
            <CardContent className="p-6">
              <div className="space-y-6">
                {mockTransactions.map((tx, index) => (
                  <div key={tx.id} className="flex items-start gap-4">
                    <div className="flex flex-col items-center">
                      <div className={`w-3 h-3 rounded-full ${
                        tx.status >= 200 && tx.status < 300 ? 'bg-green-400' : 
                        tx.status >= 400 ? 'bg-red-400' : 'bg-yellow-400'
                      }`} />
                      {index < mockTransactions.length - 1 && (
                        <div className="w-0.5 h-12 bg-border mt-1" />
                      )}
                    </div>
                    <div className="flex-1 pb-6">
                      <div className="flex items-center gap-2">
                        <MethodBadge method={tx.method} />
                        <span className="font-mono text-sm">{tx.path}</span>
                        <StatusBadge status={tx.status} />
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {new Date(tx.timestamp).toLocaleString()} • {tx.time}ms • {(tx.size / 1024).toFixed(1)}KB
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
