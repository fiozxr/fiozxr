import { useState } from 'react'
import { 
  History, 
  GitCompare, 
  Plus, 
  Minus, 
  AlertTriangle,
  ArrowRight,
  Calendar,
  CheckCircle,
  XCircle,
  RefreshCw
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { toast } from 'sonner'

// Mock data for changelog
const mockScans = [
  { id: 'scan-1', name: 'Production API Scan', date: '2024-01-15', endpoints: 156 },
  { id: 'scan-2', name: 'Production API Scan', date: '2024-01-14', endpoints: 142 },
  { id: 'scan-3', name: 'Production API Scan', date: '2024-01-13', endpoints: 138 },
]

interface Change {
  id: string
  type: 'added' | 'removed' | 'modified'
  pattern: string
  details: string
  risk?: string
  oldRisk?: string
  newRisk?: string
}

const mockChanges: Change[] = [
  {
    id: 'c1',
    type: 'added',
    pattern: '/api/v2/users/{id}',
    details: 'New API version endpoint discovered',
    risk: 'authenticated',
  },
  {
    id: 'c2',
    type: 'added',
    pattern: '/api/v1/webhooks',
    details: 'New webhook management endpoint',
    risk: 'privileged',
  },
  {
    id: 'c3',
    type: 'removed',
    pattern: '/api/v1/deprecated/legacy',
    details: 'Endpoint no longer accessible',
  },
  {
    id: 'c4',
    type: 'modified',
    pattern: '/api/v1/admin/settings',
    details: 'Authentication requirement changed',
    oldRisk: 'public',
    newRisk: 'privileged',
  },
  {
    id: 'c5',
    type: 'modified',
    pattern: '/api/internal/health',
    details: 'Response structure changed',
    oldRisk: 'sensitive',
    newRisk: 'sensitive',
  },
  {
    id: 'c6',
    type: 'added',
    pattern: '/api/v1/oauth/callback',
    details: 'OAuth callback endpoint',
    risk: 'public',
  },
]

function ChangeIcon({ type }: { type: Change['type'] }) {
  switch (type) {
    case 'added':
      return <Plus className="w-5 h-5 text-green-400" />
    case 'removed':
      return <Minus className="w-5 h-5 text-red-400" />
    case 'modified':
      return <RefreshCw className="w-5 h-5 text-yellow-400" />
  }
}

function ChangeBadge({ type }: { type: Change['type'] }) {
  const variants = {
    added: 'bg-green-500/20 text-green-400 border-green-500/30',
    removed: 'bg-red-500/20 text-red-400 border-red-500/30',
    modified: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  }
  
  return (
    <Badge variant="outline" className={variants[type]}>
      {type.charAt(0).toUpperCase() + type.slice(1)}
    </Badge>
  )
}

function RiskBadge({ risk }: { risk: string }) {
  const className = `badge-${risk}`
  return <span className={className}>{risk}</span>
}

export function Changelog() {
  const [baselineScan, setBaselineScan] = useState(mockScans[1].id)
  const [comparisonScan, setComparisonScan] = useState(mockScans[0].id)
  const [filter, setFilter] = useState<'all' | 'added' | 'removed' | 'modified'>('all')

  const filteredChanges = mockChanges.filter(change => 
    filter === 'all' || change.type === filter
  )

  const stats = {
    added: mockChanges.filter(c => c.type === 'added').length,
    removed: mockChanges.filter(c => c.type === 'removed').length,
    modified: mockChanges.filter(c => c.type === 'modified').length,
  }

  const handleCompare = () => {
    if (baselineScan === comparisonScan) {
      toast.error('Please select different scans to compare')
      return
    }
    toast.success('Comparison updated')
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Changelog</h1>
          <p className="text-muted-foreground">Track API changes over time</p>
        </div>
      </div>

      {/* Comparison Selector */}
      <Card className="xrapi-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <GitCompare className="w-5 h-5 text-primary" />
            Compare Scans
          </CardTitle>
          <CardDescription>
            Select two scan sessions to compare changes
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <label className="text-xs text-muted-foreground mb-1 block">Baseline Scan</label>
              <Select value={baselineScan} onValueChange={setBaselineScan}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {mockScans.map(scan => (
                    <SelectItem key={scan.id} value={scan.id}>
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        <span>{scan.date}</span>
                        <span className="text-muted-foreground">({scan.endpoints} endpoints)</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <ArrowRight className="w-5 h-5 text-muted-foreground mt-5" />
            
            <div className="flex-1">
              <label className="text-xs text-muted-foreground mb-1 block">Comparison Scan</label>
              <Select value={comparisonScan} onValueChange={setComparisonScan}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {mockScans.map(scan => (
                    <SelectItem key={scan.id} value={scan.id}>
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        <span>{scan.date}</span>
                        <span className="text-muted-foreground">({scan.endpoints} endpoints)</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <Button onClick={handleCompare} className="mt-5">
              Compare
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="xrapi-card border-green-500/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-3xl font-bold text-green-400">+{stats.added}</div>
                <div className="text-sm text-muted-foreground">Added</div>
              </div>
              <Plus className="w-8 h-8 text-green-400/50" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="xrapi-card border-red-500/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-3xl font-bold text-red-400">-{stats.removed}</div>
                <div className="text-sm text-muted-foreground">Removed</div>
              </div>
              <Minus className="w-8 h-8 text-red-400/50" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="xrapi-card border-yellow-500/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-3xl font-bold text-yellow-400">~{stats.modified}</div>
                <div className="text-sm text-muted-foreground">Modified</div>
              </div>
              <RefreshCw className="w-8 h-8 text-yellow-400/50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filter */}
      <div className="flex items-center gap-2">
        <span className="text-sm text-muted-foreground">Filter:</span>
        {(['all', 'added', 'removed', 'modified'] as const).map((type) => (
          <Button
            key={type}
            variant={filter === type ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter(type)}
          >
            {type.charAt(0).toUpperCase() + type.slice(1)}
          </Button>
        ))}
      </div>

      {/* Changes List */}
      <Card className="xrapi-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <History className="w-5 h-5 text-accent" />
            Changes
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredChanges.map((change) => (
              <div 
                key={change.id}
                className="flex items-start gap-4 p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors"
              >
                <div className="mt-0.5">
                  <ChangeIcon type={change.type} />
                </div>
                
                <div className="flex-1">
                  <div className="flex items-center gap-3">
                    <ChangeBadge type={change.type} />
                    <code className="text-sm font-mono">{change.pattern}</code>
                  </div>
                  
                  <p className="text-sm text-muted-foreground mt-2">
                    {change.details}
                  </p>
                  
                  {change.type === 'modified' && (change.oldRisk || change.newRisk) && (
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-xs text-muted-foreground">Risk:</span>
                      {change.oldRisk && <RiskBadge risk={change.oldRisk} />}
                      <ArrowRight className="w-4 h-4 text-muted-foreground" />
                      {change.newRisk && <RiskBadge risk={change.newRisk} />}
                    </div>
                  )}
                  
                  {change.risk && (
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-xs text-muted-foreground">Risk:</span>
                      <RiskBadge risk={change.risk} />
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
          
          {filteredChanges.length === 0 && (
            <div className="text-center py-12">
              <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-4" />
              <p className="text-muted-foreground">No changes found</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Security Alerts */}
      {stats.added > 0 && (
        <Card className="xrapi-card border-orange-500/30">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-orange-400">
              <AlertTriangle className="w-5 h-5" />
              Security Alerts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm">
                <XCircle className="w-4 h-4 text-red-400" />
                <span>2 new privileged endpoints discovered</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <AlertTriangle className="w-4 h-4 text-yellow-400" />
                <span>1 endpoint changed from public to privileged</span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
