import { useState } from 'react'
import { 
  Play, 
  Pause, 
  Settings, 
  Shield, 
  Globe, 
  FileText,
  Key,
  Clock,
  Zap,
  AlertCircle
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Slider } from '@/components/ui/slider'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { toast } from 'sonner'

interface ScanFormData {
  targetUrl: string
  name: string
  concurrency: number
  rateLimit: number
  timeout: number
  http2: boolean
  recursive: boolean
  maxDepth: number
  extensions: string[]
  headers: Record<string, string>
  authToken: string
  hideCodes: string
}

const defaultExtensions = ['', '.json', '.xml', '.api', '.yaml', '.yml']

export function ScanConfig() {
  const [isScanning, setIsScanning] = useState(false)
  const [scanProgress, setScanProgress] = useState(0)
  const [activeTab, setActiveTab] = useState('basic')
  
  const [formData, setFormData] = useState<ScanFormData>({
    targetUrl: '',
    name: '',
    concurrency: 50,
    rateLimit: 0,
    timeout: 30,
    http2: true,
    recursive: true,
    maxDepth: 3,
    extensions: defaultExtensions,
    headers: {},
    authToken: '',
    hideCodes: '',
  })

  const handleStartScan = async () => {
    if (!formData.targetUrl) {
      toast.error('Please enter a target URL')
      return
    }

    setIsScanning(true)
    toast.success('Scan started successfully')
    
    // Simulate scan progress
    const interval = setInterval(() => {
      setScanProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsScanning(false)
          toast.success('Scan completed!')
          return 100
        }
        return prev + Math.random() * 15
      })
    }, 1000)
  }

  const handleStopScan = () => {
    setIsScanning(false)
    setScanProgress(0)
    toast.info('Scan stopped')
  }

  const updateFormData = (key: keyof ScanFormData, value: any) => {
    setFormData(prev => ({ ...prev, [key]: value }))
  }

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">New Scan</h1>
          <p className="text-muted-foreground">Configure and start API endpoint discovery</p>
        </div>
        
        {isScanning && (
          <div className="flex items-center gap-3 px-4 py-2 bg-primary/10 border border-primary/20 rounded-lg">
            <div className="w-3 h-3 rounded-full bg-primary animate-pulse" />
            <span className="text-sm font-medium">Scanning...</span>
            <span className="text-sm text-muted-foreground">{Math.round(scanProgress)}%</span>
          </div>
        )}
      </div>

      {/* Scan Progress */}
      {isScanning && (
        <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
          <div 
            className="h-full bg-primary transition-all duration-500"
            style={{ width: `${scanProgress}%` }}
          />
        </div>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="basic">Basic</TabsTrigger>
          <TabsTrigger value="advanced">Advanced</TabsTrigger>
          <TabsTrigger value="auth">Authentication</TabsTrigger>
          <TabsTrigger value="wordlists">Wordlists</TabsTrigger>
        </TabsList>

        {/* Basic Configuration */}
        <TabsContent value="basic" className="space-y-4">
          <Card className="xrapi-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5 text-primary" />
                Target Configuration
              </CardTitle>
              <CardDescription>
                Specify the target API to scan
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="targetUrl">
                  Target URL <span className="text-red-400">*</span>
                </Label>
                <Input
                  id="targetUrl"
                  placeholder="https://api.example.com"
                  value={formData.targetUrl}
                  onChange={(e) => updateFormData('targetUrl', e.target.value)}
                  className="font-mono"
                />
                <p className="text-xs text-muted-foreground">
                  The base URL of the API to scan
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="scanName">Scan Name (optional)</Label>
                <Input
                  id="scanName"
                  placeholder="My API Scan"
                  value={formData.name}
                  onChange={(e) => updateFormData('name', e.target.value)}
                />
              </div>
            </CardContent>
          </Card>

          <Card className="xrapi-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5 text-accent" />
                Scan Options
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>HTTP/2 Support</Label>
                    <p className="text-xs text-muted-foreground">
                      Enable HTTP/2 for faster scanning
                    </p>
                  </div>
                  <Switch
                    checked={formData.http2}
                    onCheckedChange={(checked) => updateFormData('http2', checked)}
                  />
                </div>

                <Separator />

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Recursive Scanning</Label>
                    <p className="text-xs text-muted-foreground">
                      Follow discovered paths recursively
                    </p>
                  </div>
                  <Switch
                    checked={formData.recursive}
                    onCheckedChange={(checked) => updateFormData('recursive', checked)}
                  />
                </div>

                {formData.recursive && (
                  <div className="space-y-2 pl-4 border-l-2 border-border">
                    <Label>Max Depth</Label>
                    <Slider
                      value={[formData.maxDepth]}
                      onValueChange={([value]) => updateFormData('maxDepth', value)}
                      min={1}
                      max={10}
                      step={1}
                    />
                    <p className="text-xs text-muted-foreground">
                      Maximum recursion depth: {formData.maxDepth}
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Advanced Configuration */}
        <TabsContent value="advanced" className="space-y-4">
          <Card className="xrapi-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-yellow-400" />
                Performance
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label>Concurrency: {formData.concurrency}</Label>
                <Slider
                  value={[formData.concurrency]}
                  onValueChange={([value]) => updateFormData('concurrency', value)}
                  min={1}
                  max={200}
                  step={1}
                />
                <p className="text-xs text-muted-foreground">
                  Number of concurrent requests
                </p>
              </div>

              <div className="space-y-2">
                <Label>Rate Limit: {formData.rateLimit === 0 ? 'Unlimited' : `${formData.rateLimit} req/s`}</Label>
                <Slider
                  value={[formData.rateLimit]}
                  onValueChange={([value]) => updateFormData('rateLimit', value)}
                  min={0}
                  max={1000}
                  step={10}
                />
                <p className="text-xs text-muted-foreground">
                  Maximum requests per second (0 = unlimited)
                </p>
              </div>

              <div className="space-y-2">
                <Label>Timeout: {formData.timeout}s</Label>
                <Slider
                  value={[formData.timeout]}
                  onValueChange={([value]) => updateFormData('timeout', value)}
                  min={5}
                  max={120}
                  step={5}
                />
                <p className="text-xs text-muted-foreground">
                  Request timeout in seconds
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="xrapi-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-purple-400" />
                Extensions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {formData.extensions.map((ext, index) => (
                  <Badge 
                    key={index}
                    variant="secondary"
                    className="cursor-pointer hover:bg-destructive hover:text-destructive-foreground"
                    onClick={() => {
                      const newExtensions = formData.extensions.filter((_, i) => i !== index)
                      updateFormData('extensions', newExtensions)
                    }}
                  >
                    {ext || '(none)'}
                  </Badge>
                ))}
                <Badge 
                  variant="outline"
                  className="cursor-pointer hover:bg-primary hover:text-primary-foreground"
                  onClick={() => {
                    const newExt = prompt('Enter extension (with dot):')
                    if (newExt) {
                      updateFormData('extensions', [...formData.extensions, newExt])
                    }
                  }}
                >
                  + Add
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground mt-3">
                Click to remove, click + to add
              </p>
            </CardContent>
          </Card>

          <Card className="xrapi-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-orange-400" />
                Filtering
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="hideCodes">Hide Status Codes</Label>
                <Input
                  id="hideCodes"
                  placeholder="404, 500, 502"
                  value={formData.hideCodes}
                  onChange={(e) => updateFormData('hideCodes', e.target.value)}
                />
                <p className="text-xs text-muted-foreground">
                  Comma-separated list of status codes to hide
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Authentication */}
        <TabsContent value="auth" className="space-y-4">
          <Card className="xrapi-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Key className="w-5 h-5 text-green-400" />
                Authentication
              </CardTitle>
              <CardDescription>
                Configure authentication for authenticated scanning
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="authToken">Authorization Token</Label>
                <Input
                  id="authToken"
                  type="password"
                  placeholder="Bearer token or API key"
                  value={formData.authToken}
                  onChange={(e) => updateFormData('authToken', e.target.value)}
                  className="font-mono"
                />
                <p className="text-xs text-muted-foreground">
                  Token will be sent as Bearer authorization header
                </p>
              </div>

              <div className="p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                <div className="flex items-start gap-3">
                  <Shield className="w-5 h-5 text-yellow-400 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-yellow-400">Security Note</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Authentication tokens are stored securely and only used during scanning.
                      The scanner will compare responses between authenticated and unauthenticated requests.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Wordlists */}
        <TabsContent value="wordlists" className="space-y-4">
          <Card className="xrapi-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-blue-400" />
                Wordlists
              </CardTitle>
              <CardDescription>
                Select wordlists for endpoint discovery
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  { id: 'default', name: 'Default API Paths', entries: 150, description: 'Common API endpoints and paths' },
                  { id: 'rest', name: 'RESTful Resources', entries: 85, description: 'REST API resource names' },
                  { id: 'graphql', name: 'GraphQL Endpoints', entries: 25, description: 'Common GraphQL paths' },
                  { id: 'admin', name: 'Admin Panels', entries: 45, description: 'Administrative interfaces' },
                ].map((wl) => (
                  <div 
                    key={wl.id}
                    className="flex items-center justify-between p-3 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors cursor-pointer"
                  >
                    <div>
                      <div className="font-medium">{wl.name}</div>
                      <div className="text-xs text-muted-foreground">{wl.description}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-mono">{wl.entries}</div>
                      <div className="text-xs text-muted-foreground">entries</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Action Buttons */}
      <div className="flex items-center gap-4">
        {!isScanning ? (
          <Button 
            size="lg" 
            onClick={handleStartScan}
            className="gap-2"
          >
            <Play className="w-5 h-5" />
            Start Scan
          </Button>
        ) : (
          <Button 
            size="lg" 
            variant="destructive"
            onClick={handleStopScan}
            className="gap-2"
          >
            <Pause className="w-5 h-5" />
            Stop Scan
          </Button>
        )}
        
        <Button variant="outline" size="lg">
          <Clock className="w-5 h-5 mr-2" />
          Schedule
        </Button>
      </div>
    </div>
  )
}
