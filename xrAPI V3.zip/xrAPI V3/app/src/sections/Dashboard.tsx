import { useEffect, useRef, useState } from 'react'
import { 
  Activity, 
  Target, 
  Network, 
  Zap,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Clock
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import * as d3 from 'd3'

// Mock data for demonstration
const mockMetrics = {
  activeScans: 2,
  totalScans: 47,
  totalEndpoints: 1284,
  totalClusters: 156,
  requestsPerSecond: 45.2,
  successRate: 94.5,
}

const mockRecentTransactions = [
  { id: '1', method: 'GET', path: '/api/v1/users', status: 200, time: '12ms', timestamp: '2s ago' },
  { id: '2', method: 'POST', path: '/api/v1/auth/login', status: 401, time: '45ms', timestamp: '3s ago' },
  { id: '3', method: 'GET', path: '/api/v1/products', status: 200, time: '28ms', timestamp: '5s ago' },
  { id: '4', method: 'GET', path: '/api/internal/config', status: 403, time: '8ms', timestamp: '6s ago' },
  { id: '5', method: 'PUT', path: '/api/v1/users/123', status: 200, time: '34ms', timestamp: '8s ago' },
]

const mockGraphData = {
  nodes: [
    { id: 'root', type: 'root', label: 'API Root', risk: 'public' },
    { id: 'api', type: 'cluster', label: '/api', risk: 'public' },
    { id: 'v1', type: 'cluster', label: '/api/v1', risk: 'public' },
    { id: 'users', type: 'cluster', label: '/api/v1/users', risk: 'authenticated' },
    { id: 'products', type: 'cluster', label: '/api/v1/products', risk: 'public' },
    { id: 'auth', type: 'cluster', label: '/api/v1/auth', risk: 'public' },
    { id: 'admin', type: 'cluster', label: '/api/v1/admin', risk: 'privileged' },
    { id: 'internal', type: 'cluster', label: '/api/internal', risk: 'sensitive' },
    { id: 'user1', type: 'endpoint', label: '/users/1', risk: 'authenticated' },
    { id: 'user2', type: 'endpoint', label: '/users/2', risk: 'authenticated' },
    { id: 'product1', type: 'endpoint', label: '/products/1', risk: 'public' },
    { id: 'login', type: 'endpoint', label: '/auth/login', risk: 'public' },
  ],
  links: [
    { source: 'root', target: 'api' },
    { source: 'api', target: 'v1' },
    { source: 'api', target: 'internal' },
    { source: 'v1', target: 'users' },
    { source: 'v1', target: 'products' },
    { source: 'v1', target: 'auth' },
    { source: 'v1', target: 'admin' },
    { source: 'users', target: 'user1' },
    { source: 'users', target: 'user2' },
    { source: 'products', target: 'product1' },
    { source: 'auth', target: 'login' },
  ],
}

function MethodBadge({ method }: { method: string }) {
  const className = `method-${method.toLowerCase()}`
  return <span className={className}>{method}</span>
}

function StatusBadge({ status }: { status: number }) {
  let className = 'status-'
  if (status >= 200 && status < 300) className += '2xx'
  else if (status >= 300 && status < 400) className += '3xx'
  else if (status >= 400 && status < 500) className += '4xx'
  else className += '5xx'
  
  return <span className={className}>{status}</span>
}

interface GraphNode {
  id: string
  type: string
  label: string
  risk: string
  x?: number
  y?: number
  fx?: number | null
  fy?: number | null
}

interface GraphLink {
  source: string | GraphNode
  target: string | GraphNode
}

function APIGraph() {
  const svgRef = useRef<SVGSVGElement>(null)
  const [selectedNode, setSelectedNode] = useState<string | null>(null)

  useEffect(() => {
    if (!svgRef.current) return

    const svg = d3.select(svgRef.current)
    svg.selectAll('*').remove()

    const width = svgRef.current.clientWidth
    const height = 400
    const margin = { top: 20, right: 20, bottom: 20, left: 20 }

    svg.attr('viewBox', `0 0 ${width} ${height}`)

    // Create container group
    const g = svg.append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`)

    const innerWidth = width - margin.left - margin.right
    const innerHeight = height - margin.top - margin.bottom

    // Color scale based on risk
    const colorScale: Record<string, string> = {
      public: '#22c55e',
      authenticated: '#eab308',
      privileged: '#f97316',
      sensitive: '#ef4444',
    }

    const nodeRadius: Record<string, number> = {
      root: 25,
      cluster: 18,
      endpoint: 12,
    }

    // Prepare data
    const nodes: GraphNode[] = mockGraphData.nodes.map(n => ({ ...n }))
    const links: GraphLink[] = mockGraphData.links.map(l => ({ ...l }))

    // Create simulation
    const simulation = d3.forceSimulation<GraphNode>(nodes)
      .force('link', d3.forceLink<GraphNode, GraphLink>(links).id(d => d.id).distance(80))
      .force('charge', d3.forceManyBody().strength(-300))
      .force('center', d3.forceCenter(innerWidth / 2, innerHeight / 2))
      .force('collision', d3.forceCollide<GraphNode>().radius(d => (nodeRadius[d.type] || 15) + 5))

    // Create links
    const link = g.append('g')
      .selectAll('line')
      .data(links)
      .enter()
      .append('line')
      .attr('stroke', '#334155')
      .attr('stroke-width', 1.5)
      .attr('stroke-opacity', 0.6)

    // Create nodes
    const node = g.append('g')
      .selectAll('g')
      .data(nodes)
      .enter()
      .append('g')
      .attr('class', 'graph-node')
      .style('cursor', 'pointer')
      .call(d3.drag<SVGGElement, GraphNode>()
        .on('start', (event, d) => {
          if (!event.active) simulation.alphaTarget(0.3).restart()
          d.fx = d.x
          d.fy = d.y
        })
        .on('drag', (event, d) => {
          d.fx = event.x
          d.fy = event.y
        })
        .on('end', (event, d) => {
          if (!event.active) simulation.alphaTarget(0)
          d.fx = null
          d.fy = null
        })
      )
      .on('click', (_event, d) => {
        setSelectedNode(prev => d.id === prev ? null : d.id)
      })

    // Node circles
    node.append('circle')
      .attr('r', d => nodeRadius[d.type] || 15)
      .attr('fill', d => colorScale[d.risk] || '#64748b')
      .attr('stroke', d => d.id === selectedNode ? '#fff' : 'transparent')
      .attr('stroke-width', 2)
      .style('filter', d => `drop-shadow(0 0 8px ${colorScale[d.risk] || '#64748b'}40)`)

    // Node labels
    node.append('text')
      .text(d => d.label)
      .attr('x', d => (nodeRadius[d.type] || 15) + 5)
      .attr('y', 4)
      .attr('font-size', '11px')
      .attr('font-family', 'JetBrains Mono, monospace')
      .attr('fill', '#e2e8f0')
      .style('pointer-events', 'none')

    // Update positions on tick
    simulation.on('tick', () => {
      link
        .attr('x1', d => (d.source as GraphNode).x || 0)
        .attr('y1', d => (d.source as GraphNode).y || 0)
        .attr('x2', d => (d.target as GraphNode).x || 0)
        .attr('y2', d => (d.target as GraphNode).y || 0)

      node.attr('transform', d => `translate(${d.x || 0},${d.y || 0})`)
    })

    return () => {
      simulation.stop()
    }
  }, [selectedNode])

  return (
    <div className="relative">
      <svg 
        ref={svgRef} 
        className="w-full h-[400px]"
        style={{ minHeight: '400px' }}
      />
      
      {/* Legend */}
      <div className="absolute top-4 right-4 bg-card/90 backdrop-blur-sm border border-border rounded-lg p-3 text-xs">
        <div className="space-y-2">
          <div className="font-medium text-muted-foreground mb-2">Risk Level</div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-green-500" />
            <span>Public</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-yellow-500" />
            <span>Authenticated</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-orange-500" />
            <span>Privileged</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-red-500" />
            <span>Sensitive</span>
          </div>
        </div>
      </div>
    </div>
  )
}

export function Dashboard() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground">Real-time API security monitoring</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 px-3 py-1.5 bg-green-500/10 border border-green-500/20 rounded-full">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-xs font-medium text-green-400">System Online</span>
          </div>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="xrapi-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Activity className="w-4 h-4 text-primary" />
              Active Scans
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{mockMetrics.activeScans}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {mockMetrics.totalScans} total scans
            </p>
          </CardContent>
        </Card>

        <Card className="xrapi-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Target className="w-4 h-4 text-accent" />
              Endpoints Discovered
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{mockMetrics.totalEndpoints.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {mockMetrics.totalClusters} clusters
            </p>
          </CardContent>
        </Card>

        <Card className="xrapi-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Zap className="w-4 h-4 text-yellow-400" />
              Requests/sec
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{mockMetrics.requestsPerSecond}</div>
            <p className="text-xs text-muted-foreground mt-1">
              <TrendingUp className="w-3 h-3 inline mr-1" />
              +12% from last hour
            </p>
          </CardContent>
        </Card>

        <Card className="xrapi-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-green-400" />
              Success Rate
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{mockMetrics.successRate}%</div>
            <p className="text-xs text-muted-foreground mt-1">
              5.5% errors
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* API Graph */}
        <Card className="xrapi-card lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Network className="w-5 h-5 text-primary" />
              API Surface Graph
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <APIGraph />
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card className="xrapi-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-accent" />
              Recent Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {mockRecentTransactions.map((tx) => (
                <div 
                  key={tx.id}
                  className="flex items-center justify-between p-3 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <MethodBadge method={tx.method} />
                      <span className="text-sm font-mono text-muted-foreground truncate max-w-[120px]">
                        {tx.path}
                      </span>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {tx.timestamp}
                    </div>
                  </div>
                  <div className="text-right space-y-1">
                    <StatusBadge status={tx.status} />
                    <div className="text-xs text-muted-foreground">
                      {tx.time}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Risk Summary */}
      <Card className="xrapi-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-warning" />
            Risk Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-green-500/5 border border-green-500/20 rounded-lg">
              <div className="text-2xl font-bold text-green-400">892</div>
              <div className="text-sm text-muted-foreground mt-1">Public</div>
              <Badge variant="outline" className="mt-2 badge-public">Low Risk</Badge>
            </div>
            <div className="text-center p-4 bg-yellow-500/5 border border-yellow-500/20 rounded-lg">
              <div className="text-2xl font-bold text-yellow-400">312</div>
              <div className="text-sm text-muted-foreground mt-1">Authenticated</div>
              <Badge variant="outline" className="mt-2 badge-authenticated">Medium Risk</Badge>
            </div>
            <div className="text-center p-4 bg-orange-500/5 border border-orange-500/20 rounded-lg">
              <div className="text-2xl font-bold text-orange-400">56</div>
              <div className="text-sm text-muted-foreground mt-1">Privileged</div>
              <Badge variant="outline" className="mt-2 badge-privileged">High Risk</Badge>
            </div>
            <div className="text-center p-4 bg-red-500/5 border border-red-500/20 rounded-lg">
              <div className="text-2xl font-bold text-red-400">24</div>
              <div className="text-sm text-muted-foreground mt-1">Sensitive</div>
              <Badge variant="outline" className="mt-2 badge-sensitive">Critical</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
