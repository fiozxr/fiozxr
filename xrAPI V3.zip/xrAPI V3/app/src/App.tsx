import { useState, useEffect } from 'react'
import './App.css'
import { Sidebar } from './components/Sidebar'
import { Dashboard } from './sections/Dashboard'
import { ScanConfig } from './sections/ScanConfig'
import { ResultsExplorer } from './sections/ResultsExplorer'
import { Changelog } from './sections/Changelog'
import { Toaster } from '@/components/ui/sonner'

export type View = 'dashboard' | 'scan' | 'results' | 'changelog'

function App() {
  const [currentView, setCurrentView] = useState<View>('dashboard')
  const [isConnected, setIsConnected] = useState(false)

  // WebSocket connection for real-time updates
  useEffect(() => {
    const ws = new WebSocket('ws://localhost:8000/ws')
    
    ws.onopen = () => {
      setIsConnected(true)
      console.log('WebSocket connected')
    }
    
    ws.onclose = () => {
      setIsConnected(false)
      console.log('WebSocket disconnected')
    }
    
    ws.onmessage = (event) => {
      const data = JSON.parse(event.data)
      console.log('WebSocket message:', data)
      // Handle real-time updates
    }
    
    return () => {
      ws.close()
    }
  }, [])

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard />
      case 'scan':
        return <ScanConfig />
      case 'results':
        return <ResultsExplorer />
      case 'changelog':
        return <Changelog />
      default:
        return <Dashboard />
    }
  }

  return (
    <div className="min-h-screen bg-background flex">
      <Sidebar 
        currentView={currentView} 
        onViewChange={setCurrentView}
        isConnected={isConnected}
      />
      
      <main className="flex-1 overflow-auto">
        <div className="p-6">
          {renderView()}
        </div>
      </main>
      
      <Toaster />
    </div>
  )
}

export default App
