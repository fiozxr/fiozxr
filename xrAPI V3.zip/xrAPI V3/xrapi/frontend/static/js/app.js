/**
 * xrAPI Dashboard - Vanilla JavaScript
 * Advanced API Endpoint Discovery & Security Analysis Platform
 */

// API Configuration
const API_BASE = window.location.origin;
const WS_URL = `ws://${window.location.host}/ws`;

// State
let currentView = 'dashboard';
let ws = null;
let scanInProgress = false;
let mockData = {
    metrics: {
        activeScans: 2,
        totalEndpoints: 1284,
        requestsPerSec: 45.2,
        successRate: 94.5
    },
    riskSummary: {
        public: 892,
        authenticated: 312,
        privileged: 56,
        sensitive: 24
    },
    recentActivity: [
        { method: 'GET', path: '/api/v1/users', status: 200, time: '12ms', timestamp: '2s ago' },
        { method: 'POST', path: '/api/v1/auth/login', status: 401, time: '45ms', timestamp: '3s ago' },
        { method: 'GET', path: '/api/v1/products', status: 200, time: '28ms', timestamp: '5s ago' },
        { method: 'GET', path: '/api/internal/config', status: 403, time: '8ms', timestamp: '6s ago' },
        { method: 'PUT', path: '/api/v1/users/123', status: 200, time: '34ms', timestamp: '8s ago' }
    ],
    clusters: [
        { id: 'c1', pattern: '/api/v1/users/{id}', risk: 'authenticated', confidence: 0.95, observed: 47, samples: ['1', '2', '3', '123', '456'] },
        { id: 'c2', pattern: '/api/v1/products/{id}', risk: 'public', confidence: 0.92, observed: 128, samples: ['1', '2', 'prod-123', 'abc-456'] },
        { id: 'c3', pattern: '/api/v1/admin/{resource}', risk: 'privileged', confidence: 0.88, observed: 12, samples: ['users', 'settings', 'logs'] },
        { id: 'c4', pattern: '/api/internal/{path}', risk: 'sensitive', confidence: 0.85, observed: 8, samples: ['config', 'health', 'metrics'] },
        { id: 'c5', pattern: '/api/v1/auth/{action}', risk: 'public', confidence: 0.90, observed: 5, samples: ['login', 'logout', 'refresh'] }
    ],
    transactions: [
        { id: 't1', method: 'GET', path: '/api/v1/users/1', status: 200, time: 45, size: 2048 },
        { id: 't2', method: 'GET', path: '/api/v1/users/2', status: 200, time: 42, size: 1892 },
        { id: 't3', method: 'POST', path: '/api/v1/auth/login', status: 401, time: 156, size: 128 },
        { id: 't4', method: 'GET', path: '/api/internal/config', status: 403, time: 12, size: 64 },
        { id: 't5', method: 'GET', path: '/api/v1/admin/users', status: 200, time: 89, size: 8192 }
    ],
    scans: [
        { id: 'scan-1', name: 'Production API Scan', date: '2024-01-15', endpoints: 156 },
        { id: 'scan-2', name: 'Staging API Scan', date: '2024-01-14', endpoints: 142 },
        { id: 'scan-3', name: 'Dev API Scan', date: '2024-01-13', endpoints: 89 }
    ],
    changelog: [
        { id: 'ch1', type: 'added', pattern: '/api/v2/users/{id}', details: 'New API version endpoint discovered', risk: 'authenticated' },
        { id: 'ch2', type: 'added', pattern: '/api/v1/webhooks', details: 'New webhook management endpoint', risk: 'privileged' },
        { id: 'ch3', type: 'removed', pattern: '/api/v1/deprecated/legacy', details: 'Endpoint no longer accessible' },
        { id: 'ch4', type: 'modified', pattern: '/api/v1/admin/settings', details: 'Authentication requirement changed', oldRisk: 'public', newRisk: 'privileged' },
        { id: 'ch5', type: 'modified', pattern: '/api/internal/health', details: 'Response structure changed', oldRisk: 'sensitive', newRisk: 'sensitive' },
        { id: 'ch6', type: 'added', pattern: '/api/v1/oauth/callback', details: 'OAuth callback endpoint', risk: 'public' }
    ]
};

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    initDashboard();
    initScanForm();
    initResults();
    initChangelog();
    initWebSocket();
    initRangeInputs();
});

// Navigation
function initNavigation() {
    const navItems = document.querySelectorAll('.sidebar-nav li');
    const views = document.querySelectorAll('.view');
    const pageTitle = document.getElementById('page-title');
    
    navItems.forEach(item => {
        item.addEventListener('click', () => {
            const viewName = item.dataset.view;
            
            // Update active nav
            navItems.forEach(n => n.classList.remove('active'));
            item.classList.add('active');
            
            // Update active view
            views.forEach(v => v.classList.remove('active'));
            document.getElementById(`${viewName}-view`).classList.add('active');
            
            // Update title
            const titles = {
                dashboard: 'Dashboard',
                scan: 'New Scan',
                results: 'Results Explorer',
                changelog: 'Changelog'
            };
            pageTitle.textContent = titles[viewName];
            
            currentView = viewName;
        });
    });
}

// Dashboard
function initDashboard() {
    updateMetrics();
    renderActivityList();
    renderRiskSummary();
    renderAPIGraph();
}

function updateMetrics() {
    document.getElementById('active-scans').textContent = mockData.metrics.activeScans;
    document.getElementById('total-endpoints').textContent = mockData.metrics.totalEndpoints.toLocaleString();
    document.getElementById('requests-per-sec').textContent = mockData.metrics.requestsPerSec;
    document.getElementById('success-rate').textContent = mockData.metrics.successRate + '%';
}

function renderActivityList() {
    const container = document.getElementById('recent-activity');
    
    if (mockData.recentActivity.length === 0) {
        container.innerHTML = '<div class="empty-state">No recent activity</div>';
        return;
    }
    
    container.innerHTML = mockData.recentActivity.map(item => `
        <div class="activity-item">
            <span class="activity-method ${item.method.toLowerCase()}">${item.method}</span>
            <span class="activity-path">${item.path}</span>
            <span class="status-${Math.floor(item.status / 100)}xx">${item.status}</span>
            <span class="text-muted">${item.time}</span>
        </div>
    `).join('');
}

function renderRiskSummary() {
    document.getElementById('risk-public').textContent = mockData.riskSummary.public;
    document.getElementById('risk-authenticated').textContent = mockData.riskSummary.authenticated;
    document.getElementById('risk-privileged').textContent = mockData.riskSummary.privileged;
    document.getElementById('risk-sensitive').textContent = mockData.riskSummary.sensitive;
}

function renderAPIGraph() {
    const svg = document.getElementById('api-graph');
    const width = 800;
    const height = 400;
    
    // Graph data
    const nodes = [
        { id: 'root', x: 400, y: 50, r: 25, label: 'API Root', risk: 'public' },
        { id: 'api', x: 400, y: 120, r: 20, label: '/api', risk: 'public' },
        { id: 'v1', x: 300, y: 200, r: 18, label: '/v1', risk: 'public' },
        { id: 'v2', x: 500, y: 200, r: 18, label: '/v2', risk: 'public' },
        { id: 'users', x: 200, y: 280, r: 15, label: '/users', risk: 'authenticated' },
        { id: 'products', x: 300, y: 320, r: 15, label: '/products', risk: 'public' },
        { id: 'auth', x: 400, y: 300, r: 15, label: '/auth', risk: 'public' },
        { id: 'admin', x: 500, y: 320, r: 15, label: '/admin', risk: 'privileged' },
        { id: 'internal', x: 600, y: 280, r: 15, label: '/internal', risk: 'sensitive' }
    ];
    
    const links = [
        { source: 'root', target: 'api' },
        { source: 'api', target: 'v1' },
        { source: 'api', target: 'v2' },
        { source: 'v1', target: 'users' },
        { source: 'v1', target: 'products' },
        { source: 'v1', target: 'auth' },
        { source: 'v1', target: 'admin' },
        { source: 'v2', target: 'internal' }
    ];
    
    const riskColors = {
        public: '#3fb950',
        authenticated: '#d29922',
        privileged: '#f0883e',
        sensitive: '#f85149'
    };
    
    // Render links
    const linksHtml = links.map(link => {
        const source = nodes.find(n => n.id === link.source);
        const target = nodes.find(n => n.id === link.target);
        return `<line x1="${source.x}" y1="${source.y}" x2="${target.x}" y2="${target.y}" stroke="#30363d" stroke-width="2" />`;
    }).join('');
    
    // Render nodes
    const nodesHtml = nodes.map(node => `
        <g class="graph-node" transform="translate(${node.x}, ${node.y})">
            <circle r="${node.r}" fill="${riskColors[node.risk]}" stroke="${riskColors[node.risk]}" stroke-opacity="0.3" stroke-width="4" />
            <text y="${node.r + 15}" text-anchor="middle" fill="#7d8590" font-size="11" font-family="JetBrains Mono, monospace">${node.label}</text>
        </g>
    `).join('');
    
    svg.innerHTML = linksHtml + nodesHtml;
}

// Scan Form
function initScanForm() {
    const startBtn = document.getElementById('start-scan-btn');
    const progressDiv = document.getElementById('scan-progress');
    const progressFill = document.getElementById('progress-fill');
    
    startBtn.addEventListener('click', async () => {
        const targetUrl = document.getElementById('target-url').value;
        
        if (!targetUrl) {
            showToast('Please enter a target URL', 'error');
            return;
        }
        
        scanInProgress = true;
        progressDiv.classList.remove('hidden');
        startBtn.disabled = true;
        startBtn.innerHTML = `
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="spin">
                <circle cx="12" cy="12" r="10" stroke-dasharray="60" stroke-dashoffset="20"/>
            </svg>
            Scanning...
        `;
        
        // Simulate scan progress
        let progress = 0;
        const interval = setInterval(() => {
            progress += Math.random() * 15;
            if (progress >= 100) {
                progress = 100;
                clearInterval(interval);
                
                setTimeout(() => {
                    scanInProgress = false;
                    showToast('Scan completed successfully!', 'success');
                    startBtn.disabled = false;
                    startBtn.innerHTML = `
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polygon points="5 3 19 12 5 21 5 3"/>
                        </svg>
                        Start Scan
                    `;
                    
                    // Switch to results view
                    document.querySelector('[data-view="results"]').click();
                }, 500);
            }
            
            progressFill.style.width = progress + '%';
            document.getElementById('progress-requests').textContent = Math.floor(progress * 12.5) + ' requests';
            document.getElementById('progress-rps').textContent = (Math.random() * 50 + 20).toFixed(1) + ' RPS';
            document.getElementById('progress-clusters').textContent = Math.floor(progress / 10) + ' clusters';
        }, 500);
    });
}

function initRangeInputs() {
    const concurrency = document.getElementById('concurrency');
    const concurrencyValue = document.getElementById('concurrency-value');
    
    concurrency.addEventListener('input', () => {
        concurrencyValue.textContent = concurrency.value;
    });
    
    const rateLimit = document.getElementById('rate-limit');
    const rateLimitValue = document.getElementById('rate-limit-value');
    
    rateLimit.addEventListener('input', () => {
        rateLimitValue.textContent = rateLimit.value == 0 ? 'Unlimited' : rateLimit.value;
    });
}

// Results
function initResults() {
    renderClusters();
    renderTransactions();
    initTabs();
    initSearch();
}

function renderClusters() {
    const container = document.getElementById('clusters-list');
    
    if (mockData.clusters.length === 0) {
        container.innerHTML = '<div class="empty-state">No clusters found</div>';
        return;
    }
    
    container.innerHTML = mockData.clusters.map(cluster => `
        <div class="cluster-item">
            <div class="cluster-header" onclick="toggleCluster('${cluster.id}')">
                <span class="cluster-pattern">${cluster.pattern}</span>
                <div class="cluster-meta">
                    <span class="risk-tag ${cluster.risk}">${cluster.risk}</span>
                    <span class="text-muted">${cluster.observed} paths</span>
                    <span class="text-muted">${(cluster.confidence * 100).toFixed(0)}% conf</span>
                </div>
            </div>
        </div>
    `).join('');
}

function renderTransactions() {
    const tbody = document.getElementById('transactions-table');
    
    tbody.innerHTML = mockData.transactions.map(tx => `
        <tr>
            <td><span class="activity-method ${tx.method.toLowerCase()}">${tx.method}</span></td>
            <td style="font-family: JetBrains Mono, monospace; font-size: 0.875rem;">${tx.path}</td>
            <td class="status-${Math.floor(tx.status / 100)}xx">${tx.status}</td>
            <td>${tx.time}ms</td>
            <td>${(tx.size / 1024).toFixed(1)}KB</td>
        </tr>
    `).join('');
}

function initTabs() {
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabPanels = document.querySelectorAll('.tab-panel');
    
    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const tab = btn.dataset.tab;
            
            tabBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            tabPanels.forEach(p => p.classList.remove('active'));
            document.getElementById(`${tab}-tab`).classList.add('active');
        });
    });
}

function initSearch() {
    const searchInput = document.getElementById('results-search');
    const riskFilter = document.getElementById('risk-filter');
    
    searchInput.addEventListener('input', () => {
        filterClusters(searchInput.value, riskFilter.value);
    });
    
    riskFilter.addEventListener('change', () => {
        filterClusters(searchInput.value, riskFilter.value);
    });
}

function filterClusters(search, risk) {
    const clusters = document.querySelectorAll('.cluster-item');
    
    clusters.forEach((cluster, index) => {
        const data = mockData.clusters[index];
        const matchesSearch = data.pattern.toLowerCase().includes(search.toLowerCase());
        const matchesRisk = risk === 'all' || data.risk === risk;
        
        cluster.style.display = matchesSearch && matchesRisk ? 'block' : 'none';
    });
}

// Changelog
function initChangelog() {
    populateScanSelectors();
    initChangelogFilters();
    
    document.getElementById('compare-btn').addEventListener('click', () => {
        renderChangelog();
    });
}

function populateScanSelectors() {
    const baseline = document.getElementById('baseline-scan');
    const comparison = document.getElementById('comparison-scan');
    
    const options = mockData.scans.map(scan => 
        `<option value="${scan.id}">${scan.name} (${scan.date})</option>`
    ).join('');
    
    baseline.innerHTML = '<option value="">Select baseline scan</option>' + options;
    comparison.innerHTML = '<option value="">Select comparison scan</option>' + options;
}

function initChangelogFilters() {
    const filterBtns = document.querySelectorAll('.filter-btn');
    
    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            const filter = btn.dataset.filter;
            filterChangelog(filter);
        });
    });
}

function renderChangelog() {
    const container = document.getElementById('changelog-list');
    
    // Update stats
    const added = mockData.changelog.filter(c => c.type === 'added').length;
    const removed = mockData.changelog.filter(c => c.type === 'removed').length;
    const modified = mockData.changelog.filter(c => c.type === 'modified').length;
    
    document.getElementById('added-count').textContent = '+' + added;
    document.getElementById('removed-count').textContent = '-' + removed;
    document.getElementById('modified-count').textContent = '~' + modified;
    
    // Render changes
    container.innerHTML = mockData.changelog.map(change => `
        <div class="change-item" data-type="${change.type}">
            <svg class="change-icon ${change.type}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                ${getChangeIcon(change.type)}
            </svg>
            <div class="change-content">
                <span class="change-type ${change.type}">${change.type}</span>
                <code class="change-pattern">${change.pattern}</code>
                <p class="change-details">${change.details}</p>
                ${change.risk ? `<span class="risk-tag ${change.risk}">${change.risk}</span>` : ''}
            </div>
        </div>
    `).join('');
}

function getChangeIcon(type) {
    switch(type) {
        case 'added':
            return '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>';
        case 'removed':
            return '<line x1="5" y1="12" x2="19" y2="12"/>';
        case 'modified':
            return '<path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.3"/>';
        default:
            return '';
    }
}

function filterChangelog(filter) {
    const items = document.querySelectorAll('.change-item');
    
    items.forEach(item => {
        item.style.display = filter === 'all' || item.dataset.type === filter ? 'flex' : 'none';
    });
}

// WebSocket
function initWebSocket() {
    try {
        ws = new WebSocket(WS_URL);
        
        ws.onopen = () => {
            console.log('WebSocket connected');
            updateConnectionStatus(true);
        };
        
        ws.onclose = () => {
            console.log('WebSocket disconnected');
            updateConnectionStatus(false);
        };
        
        ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            handleWebSocketMessage(data);
        };
        
        ws.onerror = (error) => {
            console.error('WebSocket error:', error);
            updateConnectionStatus(false);
        };
    } catch (e) {
        console.log('WebSocket not available');
        updateConnectionStatus(false);
    }
}

function updateConnectionStatus(connected) {
    const dot = document.querySelector('.status-dot');
    const text = document.querySelector('.status-text');
    
    if (connected) {
        dot.classList.add('online');
        dot.classList.remove('offline');
        text.textContent = 'Connected';
    } else {
        dot.classList.remove('online');
        dot.classList.add('offline');
        text.textContent = 'Offline';
    }
}

function handleWebSocketMessage(data) {
    switch(data.type) {
        case 'transaction':
            addActivityItem(data.data);
            break;
        case 'cluster':
            updateClusters(data.data);
            break;
        case 'progress':
            updateProgress(data.data);
            break;
    }
}

// Utilities
function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

function addActivityItem(item) {
    mockData.recentActivity.unshift(item);
    if (mockData.recentActivity.length > 10) {
        mockData.recentActivity.pop();
    }
    renderActivityList();
}

function updateClusters(cluster) {
    const existing = mockData.clusters.find(c => c.pattern === cluster.pattern);
    if (!existing) {
        mockData.clusters.push(cluster);
        renderClusters();
    }
}

function updateProgress(data) {
    document.getElementById('progress-requests').textContent = data.requests + ' requests';
    document.getElementById('progress-rps').textContent = data.requests_per_second.toFixed(1) + ' RPS';
    document.getElementById('progress-clusters').textContent = data.clusters + ' clusters';
}

function toggleCluster(id) {
    // Toggle cluster expansion
    console.log('Toggle cluster:', id);
}

// Refresh button
document.getElementById('refresh-btn').addEventListener('click', () => {
    showToast('Refreshing data...', 'info');
    initDashboard();
});

// Add CSS animation for spinner
const style = document.createElement('style');
style.textContent = `
    @keyframes spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
    }
    .spin {
        animation: spin 1s linear infinite;
    }
`;
document.head.appendChild(style);
