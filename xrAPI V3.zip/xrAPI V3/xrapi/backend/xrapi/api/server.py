"""
xrAPI FastAPI Web Backend
Real-time API with WebSocket support for live scan monitoring.
"""

import asyncio
import json
import os
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Any, Dict, List, Optional
from urllib.parse import urljoin

from fastapi import (
    BackgroundTasks,
    FastAPI,
    File,
    Form,
    HTTPException,
    Query,
    UploadFile,
    WebSocket,
    WebSocketDisconnect,
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel, Field
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from xrapi.core.scanner import AsyncScanner, ScanConfig
from xrapi.db.models import (
    AuditLog,
    EndpointCluster,
    HTTPTransaction,
    RiskLevel,
    ScanSession,
    ScanSnapshot,
    ScanStatus,
    Wordlist,
    get_async_session_maker,
    init_db_async,
)
from xrapi.utils.logging import configure_logging, get_audit_logger, get_logger

logger = get_logger("xrapi.api")

# Active scan managers
active_scans: Dict[str, "ScanManager"] = {}
websocket_connections: List[WebSocket] = []


# Pydantic models for API
class ScanCreateRequest(BaseModel):
    """Request to create a new scan."""
    target_url: str
    name: Optional[str] = None
    concurrency: int = 50
    rate_limit: float = 0.0
    timeout: int = 30
    http2: bool = True
    recursive: bool = True
    max_depth: int = 3
    extensions: List[str] = Field(default_factory=lambda: ["", ".json"])
    headers: Dict[str, str] = Field(default_factory=dict)
    cookies: Dict[str, str] = Field(default_factory=dict)
    auth_tokens: Dict[str, str] = Field(default_factory=dict)
    wordlist_ids: List[str] = Field(default_factory=list)
    hide_codes: List[int] = Field(default_factory=list)
    min_response_size: int = 0
    max_response_size: int = 0


class ScanResponse(BaseModel):
    """Scan session response."""
    id: str
    name: Optional[str]
    target_url: str
    status: str
    created_at: str
    statistics: Dict[str, Any]


class ClusterResponse(BaseModel):
    """Endpoint cluster response."""
    id: str
    pattern: str
    parameter_types: List[str]
    observed_paths: List[str]
    parameter_samples: Dict[str, List[str]]
    confidence_score: float
    risk_level: str
    auth_behavior_diff: bool
    statistics: Dict[str, Any]


class TransactionResponse(BaseModel):
    """HTTP transaction response."""
    id: str
    timestamp: str
    method: str
    url: str
    path: str
    auth_state: Optional[str]
    response: Dict[str, Any]
    classification: Dict[str, Any]
    error: Optional[str]


class DashboardMetrics(BaseModel):
    """Real-time dashboard metrics."""
    active_scans: int
    total_scans: int
    total_endpoints: int
    total_clusters: int
    requests_per_second: float
    recent_transactions: List[Dict[str, Any]]


class ScanManager:
    """Manages an active scan session."""
    
    def __init__(self, session_id: str, config: ScanConfig):
        self.session_id = session_id
        self.config = config
        self.scanner = AsyncScanner(config)
        self.progress: Dict[str, Any] = {}
        self.transactions: List[Dict] = []
        self.clusters: List[Dict] = []
        self.active = False
        self.task: Optional[asyncio.Task] = None
        
        # Set up callbacks
        self.scanner.on_transaction = self._on_transaction
        self.scanner.on_cluster = self._on_cluster
    
    def _on_transaction(self, tx):
        """Handle new transaction."""
        tx_dict = tx.to_dict()
        self.transactions.append(tx_dict)
        self.progress = self.scanner._get_progress()
        
        # Broadcast to websockets
        asyncio.create_task(self._broadcast({
            "type": "transaction",
            "session_id": self.session_id,
            "data": tx_dict,
        }))
    
    def _on_cluster(self, cluster):
        """Handle new cluster."""
        cluster_dict = cluster.to_dict()
        self.clusters.append(cluster_dict)
        
        # Broadcast to websockets
        asyncio.create_task(self._broadcast({
            "type": "cluster",
            "session_id": self.session_id,
            "data": cluster_dict,
        }))
    
    async def _broadcast(self, message: Dict):
        """Broadcast message to all websocket connections."""
        disconnected = []
        for ws in websocket_connections:
            try:
                await ws.send_json(message)
            except Exception:
                disconnected.append(ws)
        
        # Remove disconnected
        for ws in disconnected:
            if ws in websocket_connections:
                websocket_connections.remove(ws)
    
    async def start(self, wordlists: Optional[List[List[str]]] = None):
        """Start the scan."""
        self.active = True
        self.task = asyncio.create_task(self._run_scan(wordlists))
    
    async def _run_scan(self, wordlists: Optional[List[List[str]]] = None):
        """Run the scan and store results."""
        try:
            results = await self.scanner.scan(wordlists)
            
            # Store results in database
            await self._save_results(results)
            
            # Broadcast completion
            await self._broadcast({
                "type": "complete",
                "session_id": self.session_id,
                "data": results,
            })
            
        except Exception as e:
            logger.error("scan.error", session_id=self.session_id, error=str(e))
            
            # Update status to failed
            session_maker = get_async_session_maker()
            async with session_maker() as session:
                await session.execute(
                    update(ScanSession)
                    .where(ScanSession.id == self.session_id)
                    .values(status=ScanStatus.FAILED)
                )
                await session.commit()
            
            await self._broadcast({
                "type": "error",
                "session_id": self.session_id,
                "error": str(e),
            })
        
        finally:
            self.active = False
            if self.session_id in active_scans:
                del active_scans[self.session_id]
    
    async def _save_results(self, results: Dict):
        """Save scan results to database."""
        session_maker = get_async_session_maker()
        async with session_maker() as session:
            # Update session
            await session.execute(
                update(ScanSession)
                .where(ScanSession.id == self.session_id)
                .values(
                    status=ScanStatus.COMPLETED,
                    completed_at=datetime.utcnow(),
                    total_requests=results["stats"]["requests"],
                    successful_requests=results["stats"]["responses"],
                    failed_requests=results["stats"]["errors"],
                    endpoints_discovered=results["discovered_endpoints"],
                    clusters_found=results["clusters"],
                )
            )
            
            # Store transactions
            for tx in self.scanner.transactions:
                parsed = tx.url.split('://', 1)[-1].split('/', 1)
                path = '/' + parsed[1] if len(parsed) > 1 else '/'
                
                db_tx = HTTPTransaction(
                    session_id=self.session_id,
                    timestamp=datetime.fromtimestamp(tx.timestamp),
                    method=tx.method,
                    url=tx.url,
                    path=path,
                    headers=tx.headers,
                    request_body=tx.request_body,
                    auth_state=tx.auth_state,
                    response_status=tx.response.status_code if tx.response else None,
                    response_headers=tx.response.headers if tx.response else {},
                    response_body=tx.response_body,
                    response_body_hash=tx.response.body_hash if tx.response else None,
                    content_type=tx.response.content_type if tx.response else None,
                    content_length=tx.response.content_length if tx.response else 0,
                    response_time_ms=tx.response_time_ms,
                    structure_signature=tx.response.structure_signature if tx.response else None,
                    body_entropy=tx.response.body_entropy if tx.response else 0.0,
                    is_error_page=tx.response.error_page if tx.response else False,
                    error_message=tx.error,
                )
                session.add(db_tx)
            
            # Store clusters
            for cluster in self.scanner.clustering.get_clusters():
                db_cluster = EndpointCluster(
                    session_id=self.session_id,
                    pattern=cluster.pattern,
                    parameter_types=[t.value for t in cluster.parameter_types],
                    observed_paths=cluster.observed_paths,
                    parameter_samples=cluster.parameter_samples,
                    confidence_score=cluster.confidence_score,
                    risk_level=cluster.risk_level.value,
                    auth_behavior_diff=cluster.auth_behavior_diff,
                    request_count=len(cluster.transactions),
                )
                session.add(db_cluster)
            
            await session.commit()
    
    def stop(self):
        """Stop the scan."""
        self.scanner.stop()
        self.active = False
        if self.task:
            self.task.cancel()
    
    def get_progress(self) -> Dict[str, Any]:
        """Get current scan progress."""
        return {
            "session_id": self.session_id,
            "active": self.active,
            "progress": self.progress,
            "transactions_count": len(self.transactions),
            "clusters_count": len(self.clusters),
        }


# FastAPI application
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager."""
    # Startup
    configure_logging(log_level="INFO", log_format="json")
    await init_db_async()
    logger.info("api.startup")
    
    yield
    
    # Shutdown
    for manager in list(active_scans.values()):
        manager.stop()
    logger.info("api.shutdown")


app = FastAPI(
    title="xrAPI",
    description="Advanced API Endpoint Discovery & Security Analysis Platform",
    version="1.0.0",
    lifespan=lifespan,
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# WebSocket endpoint for real-time updates
@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket for real-time scan updates."""
    await websocket.accept()
    websocket_connections.append(websocket)
    
    try:
        while True:
            # Keep connection alive and handle client messages
            data = await websocket.receive_json()
            
            if data.get("action") == "subscribe":
                session_id = data.get("session_id")
                if session_id and session_id in active_scans:
                    # Send current progress
                    progress = active_scans[session_id].get_progress()
                    await websocket.send_json({
                        "type": "subscribed",
                        "session_id": session_id,
                        "data": progress,
                    })
    
    except WebSocketDisconnect:
        if websocket in websocket_connections:
            websocket_connections.remove(websocket)
    except Exception as e:
        logger.error("websocket.error", error=str(e))
        if websocket in websocket_connections:
            websocket_connections.remove(websocket)


# API Routes

@app.get("/")
async def root():
    """API root."""
    return {
        "name": "xrAPI",
        "version": "1.0.0",
        "description": "Advanced API Endpoint Discovery & Security Analysis Platform",
    }


@app.get("/api/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "healthy", "timestamp": datetime.utcnow().isoformat()}


# Dashboard routes

@app.get("/api/dashboard/metrics", response_model=DashboardMetrics)
async def get_dashboard_metrics():
    """Get dashboard metrics."""
    session_maker = get_async_session_maker()
    
    async with session_maker() as session:
        # Count active scans
        active_count = len(active_scans)
        
        # Total scans
        result = await session.execute(select(ScanSession))
        total_scans = len(result.scalars().all())
        
        # Total endpoints
        result = await session.execute(select(HTTPTransaction))
        total_endpoints = len(result.scalars().all())
        
        # Total clusters
        result = await session.execute(select(EndpointCluster))
        total_clusters = len(result.scalars().all())
        
        # Recent transactions
        result = await session.execute(
            select(HTTPTransaction)
            .order_by(HTTPTransaction.timestamp.desc())
            .limit(10)
        )
        recent = [tx.to_dict() for tx in result.scalars().all()]
        
        # Calculate RPS from active scans
        total_rps = sum(
            scan.progress.get("requests_per_second", 0)
            for scan in active_scans.values()
        )
        
        return DashboardMetrics(
            active_scans=active_count,
            total_scans=total_scans,
            total_endpoints=total_endpoints,
            total_clusters=total_clusters,
            requests_per_second=total_rps,
            recent_transactions=recent,
        )


@app.get("/api/dashboard/graph")
async def get_dashboard_graph():
    """Get graph data for dashboard visualization."""
    session_maker = get_async_session_maker()
    
    async with session_maker() as session:
        # Get all clusters
        result = await session.execute(select(EndpointCluster))
        clusters = result.scalars().all()
        
        nodes = []
        links = []
        
        for cluster in clusters:
            # Create node for cluster
            node = {
                "id": cluster.id,
                "type": "cluster",
                "pattern": cluster.pattern,
                "risk": cluster.risk_level,
                "confidence": cluster.confidence_score,
            }
            nodes.append(node)
            
            # Create nodes for observed paths
            for path in cluster.observed_paths[:5]:  # Limit to 5 paths per cluster
                path_id = f"{cluster.id}:{path}"
                nodes.append({
                    "id": path_id,
                    "type": "endpoint",
                    "path": path,
                    "risk": cluster.risk_level,
                })
                links.append({
                    "source": cluster.id,
                    "target": path_id,
                })
        
        return {"nodes": nodes, "links": links}


# Scan management routes

@app.post("/api/scans", response_model=ScanResponse)
async def create_scan(request: ScanCreateRequest):
    """Create and start a new scan."""
    session_maker = get_async_session_maker()
    
    async with session_maker() as session:
        # Create scan session
        scan_session = ScanSession(
            name=request.name,
            target_url=request.target_url,
            status=ScanStatus.PENDING,
            config=request.dict(),
        )
        session.add(scan_session)
        await session.commit()
        await session.refresh(scan_session)
        
        # Load wordlists
        wordlists = []
        if request.wordlist_ids:
            for wl_id in request.wordlist_ids:
                result = await session.execute(
                    select(Wordlist).where(Wordlist.id == wl_id)
                )
                wordlist = result.scalar_one_or_none()
                if wordlist:
                    wordlists.append(wordlist.entries)
        
        # Create scan config
        config = ScanConfig(
            target_url=request.target_url,
            concurrency=request.concurrency,
            rate_limit=request.rate_limit,
            timeout=request.timeout,
            http2=request.http2,
            recursive=request.recursive,
            max_depth=request.max_depth,
            extensions=request.extensions,
            headers=request.headers,
            cookies=request.cookies,
            auth_tokens=request.auth_tokens,
            hide_codes=request.hide_codes,
            min_response_size=request.min_response_size,
            max_response_size=request.max_response_size,
        )
        
        # Create scan manager
        manager = ScanManager(scan_session.id, config)
        active_scans[scan_session.id] = manager
        
        # Update status to running
        scan_session.status = ScanStatus.RUNNING
        scan_session.started_at = datetime.utcnow()
        await session.commit()
        
        # Start scan
        await manager.start(wordlists if wordlists else None)
        
        # Audit log
        audit = get_audit_logger()
        audit.log(
            actor_type="api",
            actor_id="system",
            action="scan_create",
            resource_type="scan_session",
            resource_id=scan_session.id,
            after_state={"target": request.target_url, "config": request.dict()},
        )
        
        return ScanResponse(
            id=scan_session.id,
            name=scan_session.name,
            target_url=scan_session.target_url,
            status=scan_session.status,
            created_at=scan_session.created_at.isoformat(),
            statistics={
                "total_requests": 0,
                "successful_requests": 0,
                "failed_requests": 0,
                "endpoints_discovered": 0,
                "clusters_found": 0,
            },
        )


@app.get("/api/scans", response_model=List[ScanResponse])
async def list_scans(
    status: Optional[str] = None,
    limit: int = Query(50, ge=1, le=100),
    offset: int = Query(0, ge=0),
):
    """List scan sessions."""
    session_maker = get_async_session_maker()
    
    async with session_maker() as session:
        query = select(ScanSession).order_by(ScanSession.created_at.desc())
        
        if status:
            query = query.where(ScanSession.status == status)
        
        query = query.offset(offset).limit(limit)
        result = await session.execute(query)
        scans = result.scalars().all()
        
        return [
            ScanResponse(
                id=s.id,
                name=s.name,
                target_url=s.target_url,
                status=s.status,
                created_at=s.created_at.isoformat(),
                statistics={
                    "total_requests": s.total_requests,
                    "successful_requests": s.successful_requests,
                    "failed_requests": s.failed_requests,
                    "endpoints_discovered": s.endpoints_discovered,
                    "clusters_found": s.clusters_found,
                },
            )
            for s in scans
        ]


@app.get("/api/scans/{scan_id}", response_model=ScanResponse)
async def get_scan(scan_id: str):
    """Get scan session details."""
    session_maker = get_async_session_maker()
    
    async with session_maker() as session:
        result = await session.execute(
            select(ScanSession).where(ScanSession.id == scan_id)
        )
        scan = result.scalar_one_or_none()
        
        if not scan:
            raise HTTPException(status_code=404, detail="Scan not found")
        
        return ScanResponse(
            id=scan.id,
            name=scan.name,
            target_url=scan.target_url,
            status=scan.status,
            created_at=scan.created_at.isoformat(),
            statistics={
                "total_requests": scan.total_requests,
                "successful_requests": scan.successful_requests,
                "failed_requests": scan.failed_requests,
                "endpoints_discovered": scan.endpoints_discovered,
                "clusters_found": scan.clusters_found,
            },
        )


@app.post("/api/scans/{scan_id}/stop")
async def stop_scan(scan_id: str):
    """Stop an active scan."""
    if scan_id not in active_scans:
        raise HTTPException(status_code=404, detail="Active scan not found")
    
    manager = active_scans[scan_id]
    manager.stop()
    
    # Update status
    session_maker = get_async_session_maker()
    async with session_maker() as session:
        await session.execute(
            update(ScanSession)
            .where(ScanSession.id == scan_id)
            .values(status=ScanStatus.CANCELLED)
        )
        await session.commit()
    
    return {"message": "Scan stopped", "scan_id": scan_id}


@app.get("/api/scans/{scan_id}/progress")
async def get_scan_progress(scan_id: str):
    """Get scan progress."""
    if scan_id in active_scans:
        return active_scans[scan_id].get_progress()
    
    # Return stored progress for completed scans
    session_maker = get_async_session_maker()
    async with session_maker() as session:
        result = await session.execute(
            select(ScanSession).where(ScanSession.id == scan_id)
        )
        scan = result.scalar_one_or_none()
        
        if not scan:
            raise HTTPException(status_code=404, detail="Scan not found")
        
        return {
            "session_id": scan_id,
            "active": False,
            "status": scan.status,
            "statistics": {
                "total_requests": scan.total_requests,
                "successful_requests": scan.successful_requests,
                "failed_requests": scan.failed_requests,
                "endpoints_discovered": scan.endpoints_discovered,
                "clusters_found": scan.clusters_found,
            },
        }


# Results routes

@app.get("/api/scans/{scan_id}/clusters", response_model=List[ClusterResponse])
async def get_scan_clusters(
    scan_id: str,
    risk_level: Optional[str] = None,
    min_confidence: float = Query(0.0, ge=0.0, le=1.0),
):
    """Get endpoint clusters for a scan."""
    session_maker = get_async_session_maker()
    
    async with session_maker() as session:
        query = select(EndpointCluster).where(EndpointCluster.session_id == scan_id)
        
        if risk_level:
            query = query.where(EndpointCluster.risk_level == risk_level)
        
        query = query.where(EndpointCluster.confidence_score >= min_confidence)
        query = query.order_by(EndpointCluster.confidence_score.desc())
        
        result = await session.execute(query)
        clusters = result.scalars().all()
        
        return [
            ClusterResponse(
                id=c.id,
                pattern=c.pattern,
                parameter_types=c.parameter_types,
                observed_paths=c.observed_paths,
                parameter_samples=c.parameter_samples,
                confidence_score=c.confidence_score,
                risk_level=c.risk_level,
                auth_behavior_diff=c.auth_behavior_diff,
                statistics={
                    "request_count": c.request_count,
                    "avg_response_time_ms": c.avg_response_time_ms,
                },
            )
            for c in clusters
        ]


@app.get("/api/scans/{scan_id}/transactions", response_model=List[TransactionResponse])
async def get_scan_transactions(
    scan_id: str,
    status: Optional[int] = None,
    method: Optional[str] = None,
    path: Optional[str] = None,
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
):
    """Get HTTP transactions for a scan."""
    session_maker = get_async_session_maker()
    
    async with session_maker() as session:
        query = select(HTTPTransaction).where(HTTPTransaction.session_id == scan_id)
        
        if status:
            query = query.where(HTTPTransaction.response_status == status)
        if method:
            query = query.where(HTTPTransaction.method == method.upper())
        if path:
            query = query.where(HTTPTransaction.path.contains(path))
        
        query = query.order_by(HTTPTransaction.timestamp.desc())
        query = query.offset(offset).limit(limit)
        
        result = await session.execute(query)
        transactions = result.scalars().all()
        
        return [
            TransactionResponse(
                id=t.id,
                timestamp=t.timestamp.isoformat(),
                method=t.method,
                url=t.url,
                path=t.path,
                auth_state=t.auth_state,
                response={
                    "status": t.response_status,
                    "headers": t.response_headers,
                    "body_hash": t.response_body_hash,
                    "content_type": t.content_type,
                    "content_length": t.content_length,
                    "time_ms": t.response_time_ms,
                },
                classification={
                    "structure_signature": t.structure_signature,
                    "body_entropy": t.body_entropy,
                    "is_error_page": t.is_error_page,
                },
                error=t.error_message,
            )
            for t in transactions
        ]


@app.get("/api/scans/{scan_id}/export")
async def export_scan_results(scan_id: str, format: str = "json"):
    """Export scan results."""
    session_maker = get_async_session_maker()
    
    async with session_maker() as session:
        # Get scan
        result = await session.execute(
            select(ScanSession).where(ScanSession.id == scan_id)
        )
        scan = result.scalar_one_or_none()
        
        if not scan:
            raise HTTPException(status_code=404, detail="Scan not found")
        
        # Get clusters
        result = await session.execute(
            select(EndpointCluster).where(EndpointCluster.session_id == scan_id)
        )
        clusters = result.scalars().all()
        
        if format == "json":
            data = {
                "scan": scan.to_dict(),
                "clusters": [c.to_dict() for c in clusters],
            }
            
            return JSONResponse(
                content=data,
                headers={"Content-Disposition": f'attachment; filename="{scan_id}.json"'},
            )
        
        elif format == "openapi":
            # Generate OpenAPI spec
            spec = generate_openapi_spec(scan, clusters)
            return JSONResponse(
                content=spec,
                headers={"Content-Disposition": f'attachment; filename="{scan_id}-openapi.json"'},
            )
        
        else:
            raise HTTPException(status_code=400, detail=f"Unsupported format: {format}")


def generate_openapi_spec(scan: ScanSession, clusters: List[EndpointCluster]) -> Dict:
    """Generate OpenAPI specification from discovered endpoints."""
    paths = {}
    
    for cluster in clusters:
        path = cluster.pattern
        
        # Convert pattern to OpenAPI path template
        openapi_path = path.replace("{id}", "{id}").replace("{uuid}", "{uuid}").replace("{str}", "{name}")
        
        paths[openapi_path] = {
            "get": {
                "summary": f"Get {path}",
                "responses": {
                    "200": {
                        "description": "Success",
                    }
                }
            }
        }
    
    return {
        "openapi": "3.0.0",
        "info": {
            "title": f"Discovered API - {scan.target_url}",
            "version": "1.0.0",
            "description": f"Auto-generated from xrAPI scan on {scan.created_at}",
        },
        "servers": [
            {"url": scan.target_url}
        ],
        "paths": paths,
    }


# Wordlist routes

@app.get("/api/wordlists")
async def list_wordlists():
    """List available wordlists."""
    session_maker = get_async_session_maker()
    
    async with session_maker() as session:
        result = await session.execute(select(Wordlist))
        wordlists = result.scalars().all()
        
        return [wl.to_dict() for wl in wordlists]


@app.post("/api/wordlists")
async def create_wordlist(
    name: str = Form(...),
    description: Optional[str] = Form(None),
    entries: str = Form(...),  # JSON array as string
):
    """Create a new wordlist."""
    session_maker = get_async_session_maker()
    
    try:
        entry_list = json.loads(entries)
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON in entries")
    
    async with session_maker() as session:
        wordlist = Wordlist(
            name=name,
            description=description,
            entries=entry_list,
            entry_count=len(entry_list),
        )
        session.add(wordlist)
        await session.commit()
        await session.refresh(wordlist)
        
        return wordlist.to_dict()


# Audit log routes

@app.get("/api/audit-logs")
async def get_audit_logs(
    actor_type: Optional[str] = None,
    action: Optional[str] = None,
    limit: int = Query(100, ge=1, le=1000),
):
    """Get audit logs."""
    session_maker = get_async_session_maker()
    
    async with session_maker() as session:
        query = select(AuditLog).order_by(AuditLog.timestamp.desc())
        
        if actor_type:
            query = query.where(AuditLog.actor_type == actor_type)
        if action:
            query = query.where(AuditLog.action == action)
        
        query = query.limit(limit)
        result = await session.execute(query)
        logs = result.scalars().all()
        
        return [log.to_dict() for log in logs]


# Main entry point
def main():
    """Run the API server."""
    import uvicorn
    
    host = os.getenv("XRAPI_HOST", "0.0.0.0")
    port = int(os.getenv("XRAPI_PORT", "8000"))
    
    uvicorn.run(app, host=host, port=port)


if __name__ == "__main__":
    main()
