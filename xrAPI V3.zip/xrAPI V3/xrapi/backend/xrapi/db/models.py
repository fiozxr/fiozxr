"""
xrAPI Database Models
SQLAlchemy models for scan sessions, transactions, and audit logging.
"""

import enum
import json
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from sqlalchemy import (
    JSON,
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    create_engine,
)
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import declarative_base, relationship, sessionmaker

Base = declarative_base()


class ScanStatus(str, enum.Enum):
    """Scan session status."""
    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class RiskLevel(str, enum.Enum):
    """Endpoint risk classification."""
    PUBLIC = "public"
    AUTHENTICATED = "authenticated"
    PRIVILEGED = "privileged"
    SENSITIVE = "sensitive"


class ScanSession(Base):
    """Scan session record."""
    __tablename__ = "scan_sessions"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(255), nullable=True)
    target_url = Column(String(2048), nullable=False)
    status = Column(String(20), default=ScanStatus.PENDING)
    
    # Configuration
    config = Column(JSON, default=dict)
    
    # Timing
    created_at = Column(DateTime, default=datetime.utcnow)
    started_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    
    # Statistics
    total_requests = Column(Integer, default=0)
    successful_requests = Column(Integer, default=0)
    failed_requests = Column(Integer, default=0)
    endpoints_discovered = Column(Integer, default=0)
    clusters_found = Column(Integer, default=0)
    
    # Relationships
    transactions = relationship("HTTPTransaction", back_populates="session", cascade="all, delete-orphan")
    clusters = relationship("EndpointCluster", back_populates="session", cascade="all, delete-orphan")
    snapshots = relationship("ScanSnapshot", back_populates="session", cascade="all, delete-orphan")
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "target_url": self.target_url,
            "status": self.status,
            "config": self.config,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "statistics": {
                "total_requests": self.total_requests,
                "successful_requests": self.successful_requests,
                "failed_requests": self.failed_requests,
                "endpoints_discovered": self.endpoints_discovered,
                "clusters_found": self.clusters_found,
            },
        }


class HTTPTransaction(Base):
    """HTTP request/response transaction."""
    __tablename__ = "http_transactions"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    session_id = Column(String(36), ForeignKey("scan_sessions.id"), nullable=False)
    
    # Request details
    timestamp = Column(DateTime, default=datetime.utcnow)
    method = Column(String(10), nullable=False)
    url = Column(String(4096), nullable=False)
    path = Column(String(2048), nullable=False)
    headers = Column(JSON, default=dict)
    request_body = Column(Text, nullable=True)
    auth_state = Column(String(50), nullable=True)
    
    # Response details
    response_status = Column(Integer, nullable=True)
    response_headers = Column(JSON, default=dict)
    response_body = Column(Text, nullable=True)
    response_body_hash = Column(String(32), nullable=True)
    content_type = Column(String(255), nullable=True)
    content_length = Column(Integer, default=0)
    response_time_ms = Column(Float, default=0.0)
    
    # Classification
    structure_signature = Column(String(1024), nullable=True)
    body_entropy = Column(Float, default=0.0)
    is_error_page = Column(Boolean, default=False)
    
    # Error tracking
    error_message = Column(Text, nullable=True)
    
    # Relationships
    session = relationship("ScanSession", back_populates="transactions")
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "session_id": self.session_id,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
            "method": self.method,
            "url": self.url,
            "path": self.path,
            "headers": self.headers,
            "request_body": self.request_body,
            "auth_state": self.auth_state,
            "response": {
                "status": self.response_status,
                "headers": self.response_headers,
                "body_hash": self.response_body_hash,
                "content_type": self.content_type,
                "content_length": self.content_length,
                "time_ms": self.response_time_ms,
            },
            "classification": {
                "structure_signature": self.structure_signature,
                "body_entropy": self.body_entropy,
                "is_error_page": self.is_error_page,
            },
            "error": self.error_message,
        }


class EndpointCluster(Base):
    """Clustered endpoint pattern."""
    __tablename__ = "endpoint_clusters"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    session_id = Column(String(36), ForeignKey("scan_sessions.id"), nullable=False)
    
    # Pattern
    pattern = Column(String(2048), nullable=False)
    parameter_types = Column(JSON, default=list)
    
    # Observed instances
    observed_paths = Column(JSON, default=list)
    parameter_samples = Column(JSON, default=dict)
    
    # Analysis
    confidence_score = Column(Float, default=0.0)
    risk_level = Column(String(20), default=RiskLevel.PUBLIC)
    auth_behavior_diff = Column(Boolean, default=False)
    
    # Statistics
    request_count = Column(Integer, default=0)
    avg_response_time_ms = Column(Float, default=0.0)
    
    # Relationships
    session = relationship("ScanSession", back_populates="clusters")
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "session_id": self.session_id,
            "pattern": self.pattern,
            "parameter_types": self.parameter_types,
            "observed_paths": self.observed_paths,
            "parameter_samples": self.parameter_samples,
            "confidence_score": self.confidence_score,
            "risk_level": self.risk_level,
            "auth_behavior_diff": self.auth_behavior_diff,
            "statistics": {
                "request_count": self.request_count,
                "avg_response_time_ms": self.avg_response_time_ms,
            },
        }


class ScanSnapshot(Base):
    """Scan session snapshot for recovery."""
    __tablename__ = "scan_snapshots"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    session_id = Column(String(36), ForeignKey("scan_sessions.id"), nullable=False)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    snapshot_data = Column(JSON, default=dict)
    
    # Relationships
    session = relationship("ScanSession", back_populates="snapshots")
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "session_id": self.session_id,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class AuditLog(Base):
    """Security audit log."""
    __tablename__ = "audit_logs"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    timestamp = Column(DateTime, default=datetime.utcnow)
    
    # Actor
    actor_type = Column(String(50), nullable=False)  # "user", "api_key", "system"
    actor_id = Column(String(255), nullable=False)
    
    # Action
    action = Column(String(100), nullable=False)
    resource_type = Column(String(100), nullable=False)
    resource_id = Column(String(255), nullable=True)
    
    # Details
    before_state = Column(JSON, nullable=True)
    after_state = Column(JSON, nullable=True)
    metadata = Column(JSON, default=dict)
    
    # Integrity
    integrity_hash = Column(String(64), nullable=True)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
            "actor": {
                "type": self.actor_type,
                "id": self.actor_id,
            },
            "action": self.action,
            "resource": {
                "type": self.resource_type,
                "id": self.resource_id,
            },
            "before_state": self.before_state,
            "after_state": self.after_state,
            "metadata": self.metadata,
        }


class Wordlist(Base):
    """Custom wordlist storage."""
    __tablename__ = "wordlists"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    
    # Content
    entries = Column(JSON, default=list)
    entry_count = Column(Integer, default=0)
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)
    created_by = Column(String(255), nullable=True)
    
    # Flags
    is_default = Column(Boolean, default=False)
    is_system = Column(Boolean, default=False)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "entry_count": self.entry_count,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "is_default": self.is_default,
            "is_system": self.is_system,
        }


class ImportSource(Base):
    """Traffic import source (Burp, ZAP, etc.)."""
    __tablename__ = "import_sources"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    session_id = Column(String(36), ForeignKey("scan_sessions.id"), nullable=False)
    
    source_type = Column(String(50), nullable=False)  # "burp", "zap", "har", "openapi"
    source_name = Column(String(255), nullable=True)
    
    # Parsed data
    endpoints = Column(JSON, default=list)
    endpoint_count = Column(Integer, default=0)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "session_id": self.session_id,
            "source_type": self.source_type,
            "source_name": self.source_name,
            "endpoint_count": self.endpoint_count,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


# Database engine and session
_engine = None
_async_engine = None


def get_engine(database_url: str = "sqlite:///xrapi.db"):
    """Get or create database engine."""
    global _engine
    if _engine is None:
        _engine = create_engine(database_url, echo=False)
    return _engine


def get_async_engine(database_url: str = "sqlite+aiosqlite:///xrapi.db"):
    """Get or create async database engine."""
    global _async_engine
    if _async_engine is None:
        _async_engine = create_async_engine(database_url, echo=False)
    return _async_engine


def init_db(database_url: str = "sqlite:///xrapi.db"):
    """Initialize database tables."""
    engine = get_engine(database_url)
    Base.metadata.create_all(engine)


async def init_db_async(database_url: str = "sqlite+aiosqlite:///xrapi.db"):
    """Initialize database tables asynchronously."""
    engine = get_async_engine(database_url)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


def get_session_maker(database_url: str = "sqlite:///xrapi.db"):
    """Get session maker."""
    engine = get_engine(database_url)
    return sessionmaker(bind=engine)


def get_async_session_maker(database_url: str = "sqlite+aiosqlite:///xrapi.db"):
    """Get async session maker."""
    engine = get_async_engine(database_url)
    return sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
