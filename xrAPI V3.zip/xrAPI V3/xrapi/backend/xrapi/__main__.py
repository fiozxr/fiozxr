"""
xrAPI - Main Entry Point
"""

from xrapi.cli.main import main

if __name__ == "__main__":
    main()
