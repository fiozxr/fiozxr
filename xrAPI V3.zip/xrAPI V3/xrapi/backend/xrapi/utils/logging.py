"""
xrAPI Logging System
Structured logging with structlog for complete observability.
"""

import json
import logging
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

import structlog
from structlog.processors import (
    JSONRenderer,
    TimeStamper,
    add_log_level,
    dict_tracebacks,
    format_exc_info,
)
from structlog.stdlib import filter_by_level


class AuditLogger:
    """Cryptographically verifiable audit logging."""
    
    def __init__(self, log_dir: str = "logs"):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(exist_ok=True)
        
        self.audit_file = self.log_dir / "audit.log"
        self.last_hash = "0" * 64  # Genesis hash
        
        # Load last hash if exists
        if self.audit_file.exists():
            self._load_last_hash()
    
    def _load_last_hash(self):
        """Load the last hash from audit log."""
        try:
            with open(self.audit_file, 'r') as f:
                lines = f.readlines()
                if lines:
                    last_entry = json.loads(lines[-1])
                    self.last_hash = last_entry.get("integrity_hash", self.last_hash)
        except Exception:
            pass
    
    def _calculate_hash(self, entry: Dict[str, Any]) -> str:
        """Calculate integrity hash for entry."""
        import hashlib
        
        # Create canonical representation
        data = json.dumps(entry, sort_keys=True, separators=(',', ':'))
        data += self.last_hash  # Chain to previous
        
        return hashlib.sha256(data.encode()).hexdigest()
    
    def log(
        self,
        actor_type: str,
        actor_id: str,
        action: str,
        resource_type: str,
        resource_id: Optional[str] = None,
        before_state: Optional[Dict] = None,
        after_state: Optional[Dict] = None,
        metadata: Optional[Dict] = None,
    ) -> Dict[str, Any]:
        """Create audit log entry with integrity verification."""
        entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "actor_type": actor_type,
            "actor_id": actor_id,
            "action": action,
            "resource_type": resource_type,
            "resource_id": resource_id,
            "before_state": before_state,
            "after_state": after_state,
            "metadata": metadata or {},
            "previous_hash": self.last_hash,
        }
        
        # Calculate integrity hash
        entry["integrity_hash"] = self._calculate_hash(entry)
        self.last_hash = entry["integrity_hash"]
        
        # Write to file
        with open(self.audit_file, 'a') as f:
            f.write(json.dumps(entry) + '\n')
        
        return entry
    
    def verify_chain(self) -> bool:
        """Verify the integrity of the audit chain."""
        if not self.audit_file.exists():
            return True
        
        last_hash = "0" * 64
        
        with open(self.audit_file, 'r') as f:
            for line in f:
                entry = json.loads(line)
                
                # Verify previous hash
                if entry.get("previous_hash") != last_hash:
                    return False
                
                # Verify entry hash
                stored_hash = entry.pop("integrity_hash")
                calculated = self._calculate_hash(entry)
                
                # Restore for next iteration
                entry["integrity_hash"] = stored_hash
                
                if stored_hash != calculated:
                    return False
                
                last_hash = stored_hash
        
        return True


def configure_logging(
    log_level: str = "INFO",
    log_format: str = "json",
    log_file: Optional[str] = None,
    console_output: bool = True,
):
    """Configure structured logging for xrAPI."""
    
    # Configure standard library logging
    logging.basicConfig(
        format="%(message)s",
        stream=sys.stdout,
        level=getattr(logging, log_level.upper()),
    )
    
    # Shared processors
    shared_processors = [
        structlog.stdlib.add_log_level,
        structlog.stdlib.add_logger_name,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
    ]
    
    # Format-specific processors
    if log_format == "json":
        formatter = structlog.processors.JSONRenderer()
    else:
        formatter = structlog.dev.ConsoleRenderer(colors=True)
    
    # Configure structlog
    structlog.configure(
        processors=shared_processors + [formatter],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )
    
    # Set up file handler if specified
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(getattr(logging, log_level.upper()))
        
        if log_format == "json":
            file_formatter = logging.Formatter('%(message)s')
        else:
            file_formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
        
        file_handler.setFormatter(file_formatter)
        logging.getLogger().addHandler(file_handler)
    
    # Console handler
    if console_output:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(getattr(logging, log_level.upper()))
        logging.getLogger().addHandler(console_handler)


def get_logger(name: str = "xrapi"):
    """Get structured logger instance."""
    return structlog.get_logger(name)


class HTTPTransactionLogger:
    """Dedicated logger for HTTP transactions."""
    
    def __init__(self, db_session=None):
        self.db_session = db_session
        self.logger = get_logger("xrapi.http")
    
    def log_transaction(self, transaction: Dict[str, Any]):
        """Log HTTP transaction."""
        self.logger.info(
            "http.transaction",
            method=transaction.get("method"),
            url=transaction.get("url"),
            status=transaction.get("response", {}).get("status"),
            time_ms=transaction.get("response", {}).get("time_ms"),
            auth_state=transaction.get("auth_state"),
        )
    
    def log_error(self, error: str, context: Dict[str, Any]):
        """Log HTTP error."""
        self.logger.error(
            "http.error",
            error=error,
            **context
        )


class ScanLogger:
    """Logger for scan session events."""
    
    def __init__(self):
        self.logger = get_logger("xrapi.scan")
    
    def log_scan_start(self, session_id: str, target: str, config: Dict):
        """Log scan start."""
        self.logger.info(
            "scan.started",
            session_id=session_id,
            target=target,
            config=config,
        )
    
    def log_scan_progress(self, session_id: str, progress: Dict):
        """Log scan progress."""
        self.logger.info(
            "scan.progress",
            session_id=session_id,
            **progress
        )
    
    def log_scan_complete(self, session_id: str, results: Dict):
        """Log scan completion."""
        self.logger.info(
            "scan.completed",
            session_id=session_id,
            **results
        )
    
    def log_cluster_discovered(self, session_id: str, cluster: Dict):
        """Log discovered endpoint cluster."""
        self.logger.info(
            "scan.cluster_discovered",
            session_id=session_id,
            pattern=cluster.get("pattern"),
            confidence=cluster.get("confidence_score"),
        )
    
    def log_endpoint_found(self, session_id: str, endpoint: str, status: int):
        """Log discovered endpoint."""
        self.logger.info(
            "scan.endpoint_found",
            session_id=session_id,
            endpoint=endpoint,
            status=status,
        )


# Global audit logger instance
_audit_logger: Optional[AuditLogger] = None


def get_audit_logger(log_dir: str = "logs") -> AuditLogger:
    """Get or create global audit logger."""
    global _audit_logger
    if _audit_logger is None:
        _audit_logger = AuditLogger(log_dir)
    return _audit_logger
