#!/usr/bin/env python3
"""
xrAPI Standalone CLI - Serverless Mode
Operates without requiring a backend server.
Can optionally launch the web dashboard with --web flag.
"""

import asyncio
import json
import os
import sys
import tempfile
import webbrowser
from datetime import datetime
from pathlib import Path
from typing import List, Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from rich.table import Table
from rich.tree import Tree

from xrapi.core.scanner import AsyncScanner, ScanConfig, EndpointRisk
from xrapi.utils.logging import configure_logging, get_logger

app = typer.Typer(
    name="xrapi",
    help="xrAPI - Advanced API Endpoint Discovery & Security Analysis Platform",
    no_args_is_help=True,
    add_completion=True,
)
console = Console()
logger = get_logger("xrapi.cli")

# Default storage paths
DEFAULT_DATA_DIR = Path.home() / ".xrapi"
DEFAULT_SCANS_DIR = DEFAULT_DATA_DIR / "scans"
DEFAULT_LOGS_DIR = DEFAULT_DATA_DIR / "logs"
DEFAULT_WORDLISTS_DIR = DEFAULT_DATA_DIR / "wordlists"
DEFAULT_EXPORTS_DIR = DEFAULT_DATA_DIR / "exports"


def ensure_directories():
    """Ensure all required directories exist."""
    for dir_path in [DEFAULT_DATA_DIR, DEFAULT_SCANS_DIR, DEFAULT_LOGS_DIR, 
                     DEFAULT_WORDLISTS_DIR, DEFAULT_EXPORTS_DIR]:
        dir_path.mkdir(parents=True, exist_ok=True)


def get_scan_file_path(scan_id: str) -> Path:
    """Get the file path for a scan."""
    return DEFAULT_SCANS_DIR / f"{scan_id}.json"


def save_scan_locally(scan_data: dict) -> str:
    """Save scan results to local storage."""
    ensure_directories()
    scan_id = scan_data.get("id") or datetime.now().strftime("%Y%m%d_%H%M%S")
    file_path = get_scan_file_path(scan_id)
    
    with open(file_path, 'w') as f:
        json.dump(scan_data, f, indent=2, default=str)
    
    return str(file_path)


def load_local_scan(scan_id: str) -> Optional[dict]:
    """Load scan results from local storage."""
    file_path = get_scan_file_path(scan_id)
    
    if not file_path.exists():
        return None
    
    with open(file_path, 'r') as f:
        return json.load(f)


def list_local_scans() -> List[dict]:
    """List all locally saved scans."""
    ensure_directories()
    scans = []
    
    for scan_file in DEFAULT_SCANS_DIR.glob("*.json"):
        try:
            with open(scan_file, 'r') as f:
                scan = json.load(f)
                scan["_local_file"] = str(scan_file)
                scans.append(scan)
        except Exception:
            continue
    
    return sorted(scans, key=lambda x: x.get("created_at", ""), reverse=True)


def generate_html_report(scan_data: dict, output_path: Path):
    """Generate a standalone HTML report."""
    
    html_template = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>xrAPI Scan Report - {target}</title>
    <style>
        :root {{
            --bg: #0f1117;
            --fg: #e6edf3;
            --card: #161b22;
            --border: #30363d;
            --primary: #238636;
            --accent: #2f81f7;
            --warning: #d29922;
            --danger: #f85149;
        }}
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, monospace;
            background: var(--bg);
            color: var(--fg);
            line-height: 1.6;
            padding: 2rem;
        }}
        .header {{
            text-align: center;
            padding: 2rem;
            border-bottom: 1px solid var(--border);
            margin-bottom: 2rem;
        }}
        .header h1 {{ color: var(--primary); font-size: 2.5rem; }}
        .header .target {{ color: var(--accent); font-family: monospace; margin-top: 0.5rem; }}
        .stats {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }}
        .stat-card {{
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 1.5rem;
            text-align: center;
        }}
        .stat-card .value {{ font-size: 2rem; font-weight: bold; color: var(--primary); }}
        .stat-card .label {{ color: #8b949e; font-size: 0.875rem; }}
        .section {{
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 8px;
            margin-bottom: 1.5rem;
            overflow: hidden;
        }}
        .section-header {{
            background: rgba(48, 54, 61, 0.5);
            padding: 1rem 1.5rem;
            font-weight: 600;
            border-bottom: 1px solid var(--border);
        }}
        .section-content {{ padding: 1.5rem; }}
        table {{
            width: 100%;
            border-collapse: collapse;
            font-size: 0.875rem;
        }}
        th, td {{
            text-align: left;
            padding: 0.75rem;
            border-bottom: 1px solid var(--border);
        }}
        th {{ color: #8b949e; font-weight: 500; }}
        tr:hover {{ background: rgba(48, 54, 61, 0.3); }}
        .badge {{
            display: inline-block;
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: 500;
            text-transform: uppercase;
        }}
        .badge-public {{ background: rgba(35, 134, 54, 0.2); color: #3fb950; }}
        .badge-authenticated {{ background: rgba(210, 153, 34, 0.2); color: #d29922; }}
        .badge-privileged {{ background: rgba(248, 81, 73, 0.2); color: #f85149; }}
        .badge-sensitive {{ background: rgba(188, 76, 219, 0.2); color: #bc4cdb; }}
        .method {{
            font-family: monospace;
            font-weight: 600;
            padding: 0.125rem 0.375rem;
            border-radius: 3px;
            font-size: 0.75rem;
        }}
        .method-get {{ background: rgba(47, 129, 247, 0.2); color: #58a6ff; }}
        .method-post {{ background: rgba(35, 134, 54, 0.2); color: #3fb950; }}
        .method-put {{ background: rgba(210, 153, 34, 0.2); color: #d29922; }}
        .method-delete {{ background: rgba(248, 81, 73, 0.2); color: #f85149; }}
        .status-2xx {{ color: #3fb950; }}
        .status-3xx {{ color: #58a6ff; }}
        .status-4xx {{ color: #d29922; }}
        .status-5xx {{ color: #f85149; }}
        .footer {{
            text-align: center;
            padding: 2rem;
            color: #8b949e;
            border-top: 1px solid var(--border);
            margin-top: 2rem;
        }}
        code {{
            font-family: 'SF Mono', Monaco, monospace;
            background: rgba(48, 54, 61, 0.5);
            padding: 0.125rem 0.375rem;
            border-radius: 3px;
            font-size: 0.875rem;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>xrAPI Scan Report</h1>
        <div class="target">{target}</div>
        <div style="color: #8b949e; margin-top: 0.5rem;">{date}</div>
    </div>
    
    <div class="stats">
        <div class="stat-card">
            <div class="value">{duration}</div>
            <div class="label">Duration</div>
        </div>
        <div class="stat-card">
            <div class="value">{requests}</div>
            <div class="label">Requests</div>
        </div>
        <div class="stat-card">
            <div class="value">{endpoints}</div>
            <div class="label">Endpoints</div>
        </div>
        <div class="stat-card">
            <div class="value">{clusters}</div>
            <div class="label">Clusters</div>
        </div>
    </div>
    
    <div class="section">
        <div class="section-header">Discovered Clusters</div>
        <div class="section-content">
            <table>
                <thead>
                    <tr>
                        <th>Pattern</th>
                        <th>Observed</th>
                        <th>Confidence</th>
                        <th>Risk Level</th>
                    </tr>
                </thead>
                <tbody>
                    {clusters_rows}
                </tbody>
            </table>
        </div>
    </div>
    
    <div class="section">
        <div class="section-header">HTTP Transactions</div>
        <div class="section-content">
            <table>
                <thead>
                    <tr>
                        <th>Method</th>
                        <th>Path</th>
                        <th>Status</th>
                        <th>Time</th>
                    </tr>
                </thead>
                <tbody>
                    {transactions_rows}
                </tbody>
            </table>
        </div>
    </div>
    
    <div class="footer">
        Generated by xrAPI - Advanced API Endpoint Discovery & Security Analysis Platform
    </div>
</body>
</html>"""
    
    # Generate clusters rows
    clusters_rows = ""
    for cluster in scan_data.get("clusters", [])[:50]:
        risk_class = f"badge-{cluster.get('risk_level', 'public')}"
        clusters_rows += f"""
        <tr>
            <td><code>{cluster.get('pattern', 'N/A')}</code></td>
            <td>{len(cluster.get('observed_paths', []))}</td>
            <td>{cluster.get('confidence_score', 0):.0%}</td>
            <td><span class="badge {risk_class}">{cluster.get('risk_level', 'public')}</span></td>
        </tr>"""
    
    # Generate transactions rows
    transactions_rows = ""
    for tx in scan_data.get("transactions", [])[:100]:
        method = tx.get('method', 'GET')
        status = tx.get('response', {}).get('status', 0)
        status_class = f"status-{str(status)[0]}xx" if status else ""
        time_ms = tx.get('response_time_ms', 0)
        
        transactions_rows += f"""
        <tr>
            <td><span class="method method-{method.lower()}">{method}</span></td>
            <td><code>{tx.get('path', 'N/A')}</code></td>
            <td class="{status_class}">{status}</td>
            <td>{time_ms:.0f}ms</td>
        </tr>"""
    
    # Fill template
    html = html_template.format(
        target=scan_data.get("target", "Unknown"),
        date=scan_data.get("created_at", datetime.now().isoformat()),
        duration=f"{scan_data.get('duration_seconds', 0):.1f}s",
        requests=scan_data.get("stats", {}).get("requests", 0),
        endpoints=scan_data.get("discovered_endpoints", 0),
        clusters=len(scan_data.get("clusters", [])),
        clusters_rows=clusters_rows,
        transactions_rows=transactions_rows,
    )
    
    with open(output_path, 'w') as f:
        f.write(html)
    
    return str(output_path)


@app.command()
def scan(
    target: str = typer.Argument(..., help="Target URL to scan"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Scan name for identification"),
    wordlist: Optional[List[str]] = typer.Option(None, "--wordlist", "-w", help="Wordlist file(s)"),
    concurrency: int = typer.Option(50, "--concurrency", "-c", help="Concurrent requests (1-200)"),
    rate_limit: float = typer.Option(0.0, "--rate-limit", "-r", help="Requests per second (0=unlimited)"),
    timeout: int = typer.Option(30, "--timeout", "-t", help="Request timeout in seconds"),
    extensions: str = typer.Option("",.json,.xml", "--extensions", "-e", help="File extensions to try"),
    headers: Optional[List[str]] = typer.Option(None, "--header", "-H", help="Custom headers (Key:Value)"),
    cookie: Optional[str] = typer.Option(None, "--cookie", help="Cookie string"),
    auth: Optional[str] = typer.Option(None, "--auth", "-a", help="Authorization token (Bearer/API key)"),
    proxy: Optional[str] = typer.Option(None, "--proxy", "-p", help="Proxy URL (http://proxy:8080)"),
    http2: bool = typer.Option(True, "--http2/--no-http2", help="Enable HTTP/2 support"),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Output file path"),
    format: str = typer.Option("json", "--format", "-f", help="Output format: json, csv, html"),
    hide_codes: Optional[str] = typer.Option(None, "--hide-codes", help="Hide status codes (404,500,502)"),
    web: bool = typer.Option(False, "--web", "-W", help="Launch web dashboard after scan"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Verbose output"),
    no_save: bool = typer.Option(False, "--no-save", help="Don't save scan to local storage"),
):
    """Start a new API endpoint discovery scan (serverless mode)."""
    
    configure_logging(log_level="DEBUG" if verbose else "INFO")
    ensure_directories()
    
    # Parse extensions
    ext_list = [e.strip() for e in extensions.split(",") if e.strip()]
    
    # Parse headers
    header_dict = {}
    if headers:
        for h in headers:
            if ":" in h:
                key, value = h.split(":", 1)
                header_dict[key.strip()] = value.strip()
    
    # Parse cookies
    cookie_dict = {}
    if cookie:
        for c in cookie.split(";"):
            if "=" in c:
                key, value = c.split("=", 1)
                cookie_dict[key.strip()] = value.strip()
    
    # Parse auth tokens
    auth_tokens = {}
    if auth:
        auth_tokens["authenticated"] = auth
    
    # Parse hide codes
    hide_list = []
    if hide_codes:
        hide_list = [int(c.strip()) for c in hide_codes.split(",") if c.strip().isdigit()]
    
    # Load wordlists
    wordlists = []
    if wordlist:
        for wl_path in wordlist:
            try:
                with open(wl_path, 'r') as f:
                    wordlists.append([line.strip() for line in f if line.strip()])
            except FileNotFoundError:
                console.print(f"[red]Wordlist not found: {wl_path}[/red]")
                raise typer.Exit(1)
    
    # Create config
    config = ScanConfig(
        target_url=target,
        concurrency=concurrency,
        rate_limit=rate_limit,
        timeout=timeout,
        extensions=ext_list,
        headers=header_dict,
        cookies=cookie_dict,
        auth_tokens=auth_tokens,
        proxy=proxy,
        http2=http2,
        hide_codes=hide_list,
    )
    
    async def run_scan():
        scan_name = name or f"scan_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        console.print(Panel(f"[bold green]xrAPI Scan[/bold green]\n[cyan]{target}[/cyan]"))
        console.print(f"Scan Name: {scan_name}")
        console.print(f"Concurrency: {concurrency}, Rate limit: {rate_limit or 'unlimited'}")
        console.print()
        
        scanner = AsyncScanner(config)
        
        # Progress tracking
        progress_data = {"requests": 0, "clusters": 0, "rps": 0.0}
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            console=console,
        ) as progress:
            task = progress.add_task("[cyan]Scanning...", total=None)
            
            def on_progress(p):
                progress_data.update(p)
                progress.update(task, description=f"[cyan]Requests: {p['requests']} | RPS: {p['requests_per_second']:.1f} | Clusters: {p['clusters']}")
            
            results = await scanner.scan(wordlists if wordlists else None, on_progress=on_progress)
            progress.update(task, completed=True)
        
        # Prepare scan data
        scan_data = {
            "id": scan_name,
            "name": scan_name,
            "target": target,
            "created_at": datetime.now().isoformat(),
            "config": config.to_dict(),
            "duration_seconds": results["duration_seconds"],
            "stats": results["stats"],
            "discovered_endpoints": results["discovered_endpoints"],
            "clusters": [c.to_dict() for c in scanner.clustering.get_clusters()],
            "transactions": [tx.to_dict() for tx in scanner.transactions[:5000]],  # Limit for storage
        }
        
        # Save locally
        if not no_save:
            saved_path = save_scan_locally(scan_data)
            console.print(f"\n[green]Scan saved to:[/green] {saved_path}")
        
        # Export if requested
        if output:
            output_path = Path(output)
            
            if format == "json":
                with open(output_path, 'w') as f:
                    json.dump(scan_data, f, indent=2, default=str)
                console.print(f"[green]Exported to:[/green] {output_path}")
            
            elif format == "csv":
                import csv
                with open(output_path, 'w', newline='') as f:
                    writer = csv.writer(f)
                    writer.writerow(["pattern", "observed_count", "confidence", "risk_level"])
                    for c in scan_data["clusters"]:
                        writer.writerow([c["pattern"], len(c.get("observed_paths", [])), 
                                       c.get("confidence_score", 0), c.get("risk_level", "")])
                console.print(f"[green]Exported to:[/green] {output_path}")
            
            elif format == "html":
                generate_html_report(scan_data, output_path)
                console.print(f"[green]HTML report saved to:[/green] {output_path}")
        
        # Display results
        console.print()
        console.print(Panel("[bold green]Scan Complete[/bold green]"))
        
        summary = Table(title="Scan Summary")
        summary.add_column("Metric", style="cyan")
        summary.add_column("Value", style="green")
        
        summary.add_row("Duration", f"{results['duration_seconds']:.2f}s")
        summary.add_row("Total Requests", str(results["stats"]["requests"]))
        summary.add_row("Successful", str(results["stats"]["responses"]))
        summary.add_row("Failed", str(results["stats"]["errors"]))
        summary.add_row("Endpoints Discovered", str(results["discovered_endpoints"]))
        summary.add_row("Clusters Found", str(results["clusters"]))
        
        console.print(summary)
        console.print()
        
        # Display clusters
        clusters = scanner.clustering.get_clusters()
        if clusters:
            cluster_table = Table(title="Top Discovered Clusters")
            cluster_table.add_column("Pattern", style="cyan")
            cluster_table.add_column("Observed", style="green")
            cluster_table.add_column("Confidence", style="yellow")
            cluster_table.add_column("Risk", style="red")
            
            for cluster in clusters[:15]:
                risk_color = {
                    "public": "green",
                    "authenticated": "yellow",
                    "privileged": "red",
                    "sensitive": "red",
                }.get(cluster.risk_level.value, "white")
                
                cluster_table.add_row(
                    cluster.pattern,
                    str(len(cluster.observed_paths)),
                    f"{cluster.confidence_score:.0%}",
                    f"[{risk_color}]{cluster.risk_level.value}[/{risk_color}]",
                )
            
            console.print(cluster_table)
        
        # Launch web dashboard if requested
        if web:
            console.print()
            console.print("[cyan]Launching web dashboard...[/cyan]")
            launch_dashboard(scan_data)
        
        return scan_data
    
    try:
        return asyncio.run(run_scan())
    except KeyboardInterrupt:
        console.print("\n[yellow]Scan interrupted by user[/yellow]")
        raise typer.Exit(130)
    except Exception as e:
        console.print(f"\n[red]Error: {e}[/red]")
        logger.error("scan.error", error=str(e))
        raise typer.Exit(1)


@app.command()
def list(
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed information"),
    limit: int = typer.Option(20, "--limit", "-l", help="Maximum results to show"),
):
    """List all locally saved scans."""
    
    scans = list_local_scans()
    
    if not scans:
        console.print("[yellow]No saved scans found[/yellow]")
        console.print(f"Scans are saved in: {DEFAULT_SCANS_DIR}")
        return
    
    console.print(Panel(f"[bold]Saved Scans[/bold] ({len(scans)} total)"))
    
    table = Table()
    table.add_column("ID", style="dim")
    table.add_column("Name")
    table.add_column("Target", style="cyan")
    table.add_column("Date", style="yellow")
    table.add_column("Endpoints", justify="right")
    table.add_column("Clusters", justify="right")
    
    for scan in scans[:limit]:
        table.add_row(
            scan.get("id", "N/A")[:12],
            scan.get("name", "-")[:30],
            scan.get("target", scan.get("target_url", "-"))[:40],
            scan.get("created_at", "-")[:19],
            str(scan.get("discovered_endpoints", 0)),
            str(len(scan.get("clusters", []))),
        )
    
    console.print(table)
    
    if len(scans) > limit:
        console.print(f"\n[dim]... and {len(scans) - limit} more scans[/dim]")


@app.command()
def show(
    scan_id: str = typer.Argument(..., help="Scan ID to display"),
    clusters: bool = typer.Option(True, "--clusters/--no-clusters", help="Show clusters"),
    transactions: bool = typer.Option(False, "--transactions", help="Show transactions"),
):
    """Show detailed information about a saved scan."""
    
    scan = load_local_scan(scan_id)
    
    if not scan:
        # Try partial match
        scans = list_local_scans()
        for s in scans:
            if s.get("id", "").startswith(scan_id):
                scan = s
                break
    
    if not scan:
        console.print(f"[red]Scan not found: {scan_id}[/red]")
        raise typer.Exit(1)
    
    console.print(Panel(f"[bold]{scan.get('name', 'Scan')}[/bold]"))
    console.print(f"ID: {scan.get('id')}")
    console.print(f"Target: [cyan]{scan.get('target', scan.get('target_url', 'N/A'))}[/cyan]")
    console.print(f"Created: {scan.get('created_at')}")
    console.print()
    
    stats = scan.get("stats", {})
    console.print("[bold]Statistics:[/bold]")
    console.print(f"  Requests: {stats.get('requests', 0)}")
    console.print(f"  Successful: {stats.get('responses', 0)}")
    console.print(f"  Failed: {stats.get('errors', 0)}")
    console.print(f"  Duration: {scan.get('duration_seconds', 0):.2f}s")
    console.print()
    
    if clusters:
        cluster_list = scan.get("clusters", [])
        if cluster_list:
            console.print(f"[bold]Clusters ({len(cluster_list)}):[/bold]")
            
            tree = Tree("[cyan]Endpoints[/cyan]")
            
            for cluster in cluster_list[:20]:
                risk = cluster.get("risk_level", "public")
                risk_color = {
                    "public": "green",
                    "authenticated": "yellow",
                    "privileged": "red",
                    "sensitive": "red",
                }.get(risk, "white")
                
                observed = cluster.get("observed_paths", [])
                node = tree.add(
                    f"[{risk_color}]{cluster.get('pattern')}[/{risk_color}] "
                    f"(conf: {cluster.get('confidence_score', 0):.0%}, obs: {len(observed)})"
                )
                
                for path in observed[:5]:
                    node.add(f"[dim]{path}[/dim]")
                
                if len(observed) > 5:
                    node.add(f"[dim]... and {len(observed) - 5} more[/dim]")
            
            console.print(tree)


@app.command()
def export(
    scan_id: str = typer.Argument(..., help="Scan ID to export"),
    output: str = typer.Option(..., "--output", "-o", help="Output file path"),
    format: str = typer.Option("json", "--format", "-f", help="Export format: json, csv, html, openapi"),
    open_file: bool = typer.Option(False, "--open", help="Open the exported file after creation"),
):
    """Export a scan to various formats."""
    
    scan = load_local_scan(scan_id)
    
    if not scan:
        console.print(f"[red]Scan not found: {scan_id}[/red]")
        raise typer.Exit(1)
    
    output_path = Path(output)
    
    if format == "json":
        with open(output_path, 'w') as f:
            json.dump(scan, f, indent=2, default=str)
        console.print(f"[green]Exported to {output_path}[/green]")
    
    elif format == "csv":
        import csv
        with open(output_path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["pattern", "observed_count", "confidence", "risk_level"])
            for c in scan.get("clusters", []):
                writer.writerow([c.get("pattern"), len(c.get("observed_paths", [])),
                               c.get("confidence_score", 0), c.get("risk_level", "")])
        console.print(f"[green]Exported to {output_path}[/green]")
    
    elif format == "html":
        generate_html_report(scan, output_path)
        console.print(f"[green]HTML report saved to {output_path}[/green]")
    
    elif format == "openapi":
        spec = {
            "openapi": "3.0.0",
            "info": {
                "title": f"Discovered API - {scan.get('target', 'Unknown')}",
                "version": "1.0.0",
                "description": f"Auto-generated from xrAPI scan on {scan.get('created_at')}",
            },
            "servers": [{"url": scan.get("target", "")}],
            "paths": {},
        }
        
        for cluster in scan.get("clusters", []):
            path = cluster.get("pattern", "").replace("{id}", "{id}").replace("{uuid}", "{uuid}").replace("{str}", "{name}")
            if path:
                spec["paths"][path] = {
                    "get": {
                        "summary": f"Get {cluster.get('pattern')}",
                        "responses": {"200": {"description": "Success"}},
                    }
                }
        
        with open(output_path, 'w') as f:
            json.dump(spec, f, indent=2)
        console.print(f"[green]OpenAPI spec saved to {output_path}[/green]")
    
    else:
        console.print(f"[red]Unsupported format: {format}[/red]")
        raise typer.Exit(1)
    
    if open_file:
        webbrowser.open(f"file://{output_path.absolute()}")


@app.command()
def diff(
    scan1: str = typer.Argument(..., help="First scan ID (baseline)"),
    scan2: str = typer.Argument(..., help="Second scan ID (comparison)"),
):
    """Compare two scans and show differences."""
    
    s1 = load_local_scan(scan1)
    s2 = load_local_scan(scan2)
    
    if not s1:
        console.print(f"[red]Scan not found: {scan1}[/red]")
        raise typer.Exit(1)
    if not s2:
        console.print(f"[red]Scan not found: {scan2}[/red]")
        raise typer.Exit(1)
    
    clusters1 = {c.get("pattern"): c for c in s1.get("clusters", [])}
    clusters2 = {c.get("pattern"): c for c in s2.get("clusters", [])}
    
    added = set(clusters2.keys()) - set(clusters1.keys())
    removed = set(clusters1.keys()) - set(clusters2.keys())
    common = set(clusters1.keys()) & set(clusters2.keys())
    
    console.print(Panel(f"[bold]Diff: {s1.get('target', 'Unknown')}[/bold]"))
    console.print(f"Baseline: {s1.get('created_at')}")
    console.print(f"Comparison: {s2.get('created_at')}")
    console.print()
    
    if added:
        console.print(f"[green]Added endpoints ({len(added)}):[/green]")
        for pattern in sorted(added):
            c = clusters2[pattern]
            console.print(f"  [green]+[/green] {pattern} ({c.get('risk_level', 'unknown')})")
        console.print()
    
    if removed:
        console.print(f"[red]Removed endpoints ({len(removed)}):[/red]")
        for pattern in sorted(removed):
            console.print(f"  [red]-[/red] {pattern}")
        console.print()
    
    # Check for risk changes
    risk_changes = []
    for pattern in common:
        r1 = clusters1[pattern].get("risk_level")
        r2 = clusters2[pattern].get("risk_level")
        if r1 != r2:
            risk_changes.append((pattern, r1, r2))
    
    if risk_changes:
        console.print(f"[yellow]Risk level changes ({len(risk_changes)}):[/yellow]")
        for pattern, old, new in risk_changes:
            console.print(f"  [yellow]~[/yellow] {pattern}: {old} -> {new}")


@app.command()
def logs(
    follow: bool = typer.Option(False, "--follow", "-f", help="Follow log output"),
    lines: int = typer.Option(50, "--lines", "-n", help="Number of lines to show"),
):
    """View xrAPI logs."""
    
    log_file = DEFAULT_LOGS_DIR / "xrapi.log"
    
    if not log_file.exists():
        console.print("[yellow]No log file found[/yellow]")
        return
    
    if follow:
        console.print(f"[cyan]Following {log_file}... (Ctrl+C to exit)[/cyan]")
        try:
            import time
            with open(log_file, 'r') as f:
                f.seek(0, 2)  # Go to end
                while True:
                    line = f.readline()
                    if line:
                        console.print(line.rstrip())
                    else:
                        time.sleep(0.1)
        except KeyboardInterrupt:
            console.print("\n[yellow]Stopped following logs[/yellow]")
    else:
        with open(log_file, 'r') as f:
            all_lines = f.readlines()
            for line in all_lines[-lines:]:
                console.print(line.rstrip())


def launch_dashboard(scan_data: Optional[dict] = None):
    """Launch the web dashboard."""
    
    try:
        # Try to import and launch the web server
        from xrapi.cli.web import launch_web_server
        launch_web_server(scan_data)
    except ImportError:
        console.print("[yellow]Web dashboard not available. Install with: pip install xrapi[web][/yellow]")
        
        # Fallback: open the static HTML report
        if scan_data:
            html_path = DEFAULT_EXPORTS_DIR / f"{scan_data.get('id', 'report')}.html"
            generate_html_report(scan_data, html_path)
            webbrowser.open(f"file://{html_path.absolute()}")
            console.print(f"[green]Opened HTML report: {html_path}[/green]")


@app.command()
def dashboard(
    scan_id: Optional[str] = typer.Option(None, "--scan", "-s", help="Load specific scan"),
    port: int = typer.Option(8080, "--port", "-p", help="Dashboard port"),
    no_browser: bool = typer.Option(False, "--no-browser", help="Don't open browser automatically"),
):
    """Launch the xrAPI web dashboard."""
    
    scan_data = None
    if scan_id:
        scan_data = load_local_scan(scan_id)
        if not scan_data:
            console.print(f"[red]Scan not found: {scan_id}[/red]")
            raise typer.Exit(1)
    
    console.print(Panel("[bold green]xrAPI Web Dashboard[/bold green]"))
    console.print(f"Starting server on [cyan]http://localhost:{port}[/cyan]")
    console.print()
    
    if not no_browser:
        import threading
        import time
        
        def open_browser():
            time.sleep(1.5)
            webbrowser.open(f"http://localhost:{port}")
        
        threading.Thread(target=open_browser, daemon=True).start()
    
    try:
        from xrapi.cli.web import launch_web_server
        launch_web_server(scan_data, port=port)
    except ImportError:
        console.print("[red]Web dashboard not available.[/red]")
        console.print("[yellow]To use the dashboard, ensure all web dependencies are installed.[/yellow]")
        raise typer.Exit(1)


@app.command()
def wordlist(
    action: str = typer.Argument(..., help="Action: list, add, remove"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Wordlist name"),
    file: Optional[str] = typer.Option(None, "--file", "-f", help="Wordlist file path"),
):
    """Manage custom wordlists."""
    
    if action == "list":
        wordlists = list(DEFAULT_WORDLISTS_DIR.glob("*.txt"))
        
        if not wordlists:
            console.print("[yellow]No custom wordlists found[/yellow]")
            console.print(f"Wordlists are stored in: {DEFAULT_WORDLISTS_DIR}")
            return
        
        table = Table(title="Custom Wordlists")
        table.add_column("Name")
        table.add_column("Entries", justify="right")
        table.add_column("Size")
        
        for wl in wordlists:
            with open(wl, 'r') as f:
                entries = len([l for l in f if l.strip()])
            size = wl.stat().st_size
            table.add_row(wl.stem, str(entries), f"{size} bytes")
        
        console.print(table)
    
    elif action == "add":
        if not name or not file:
            console.print("[red]Both --name and --file are required[/red]")
            raise typer.Exit(1)
        
        source_path = Path(file)
        if not source_path.exists():
            console.print(f"[red]File not found: {file}[/red]")
            raise typer.Exit(1)
        
        dest_path = DEFAULT_WORDLISTS_DIR / f"{name}.txt"
        
        import shutil
        shutil.copy(source_path, dest_path)
        
        with open(dest_path, 'r') as f:
            entries = len([l for l in f if l.strip()])
        
        console.print(f"[green]Added wordlist '{name}' with {entries} entries[/green]")
    
    elif action == "remove":
        if not name:
            console.print("[red]--name is required[/red]")
            raise typer.Exit(1)
        
        wl_path = DEFAULT_WORDLISTS_DIR / f"{name}.txt"
        
        if not wl_path.exists():
            console.print(f"[red]Wordlist not found: {name}[/red]")
            raise typer.Exit(1)
        
        wl_path.unlink()
        console.print(f"[green]Removed wordlist '{name}'[/green]")
    
    else:
        console.print(f"[red]Unknown action: {action}[/red]")
        raise typer.Exit(1)


@app.callback()
def main_callback(
    version: bool = typer.Option(False, "--version", "-v", help="Show version"),
    data_dir: Optional[str] = typer.Option(None, "--data-dir", help="Custom data directory"),
):
    """xrAPI - Advanced API Endpoint Discovery & Security Analysis Platform"""
    
    global DEFAULT_DATA_DIR, DEFAULT_SCANS_DIR, DEFAULT_LOGS_DIR
    global DEFAULT_WORDLISTS_DIR, DEFAULT_EXPORTS_DIR
    
    if version:
        console.print("xrAPI v1.0.0")
        console.print("Advanced API Endpoint Discovery & Security Analysis Platform")
        raise typer.Exit()
    
    if data_dir:
        DEFAULT_DATA_DIR = Path(data_dir)
        DEFAULT_SCANS_DIR = DEFAULT_DATA_DIR / "scans"
        DEFAULT_LOGS_DIR = DEFAULT_DATA_DIR / "logs"
        DEFAULT_WORDLISTS_DIR = DEFAULT_DATA_DIR / "wordlists"
        DEFAULT_EXPORTS_DIR = DEFAULT_DATA_DIR / "exports"
    
    ensure_directories()


def main():
    """Entry point for the CLI."""
    app()


if __name__ == "__main__":
    main()
