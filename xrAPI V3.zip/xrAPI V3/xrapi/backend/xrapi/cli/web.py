#!/usr/bin/env python3
"""
xrAPI Web Dashboard Launcher
Standalone web server for the xrAPI dashboard.
"""

import os
import sys
import json
import webbrowser
from pathlib import Path
from typing import Optional, Dict, Any
from datetime import datetime

import uvicorn
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse

# Try to find the frontend dist directory
def get_frontend_path() -> Path:
    """Get the path to the frontend dist directory."""
    # Check multiple locations
    possible_paths = [
        Path(__file__).parent.parent.parent.parent.parent / "frontend" / "dist",
        Path(__file__).parent.parent.parent / "frontend" / "dist",
        Path.home() / ".xrapi" / "frontend" / "dist",
        Path("/usr/share/xrapi/frontend/dist"),
        Path("/opt/xrapi/frontend/dist"),
    ]
    
    for path in possible_paths:
        if path.exists() and (path / "index.html").exists():
            return path
    
    # Return default even if not found
    return possible_paths[0]


def create_standalone_app(scan_data: Optional[Dict[str, Any]] = None) -> FastAPI:
    """Create a standalone FastAPI app for the dashboard."""
    
    app = FastAPI(
        title="xrAPI Dashboard",
        description="Advanced API Endpoint Discovery & Security Analysis",
        version="1.0.0",
    )
    
    # Store scan data in memory
    scans_store: Dict[str, Any] = {}
    
    if scan_data:
        scans_store[scan_data.get("id", "current")] = scan_data
    
    @app.get("/api/health")
    async def health():
        return {"status": "healthy", "timestamp": datetime.now().isoformat()}
    
    @app.get("/api/scans")
    async def list_scans():
        """List available scans."""
        return {
            "scans": [
                {
                    "id": scan_id,
                    "name": data.get("name", scan_id),
                    "target": data.get("target", data.get("target_url", "Unknown")),
                    "created_at": data.get("created_at"),
                    "endpoints": data.get("discovered_endpoints", 0),
                    "clusters": len(data.get("clusters", [])),
                }
                for scan_id, data in scans_store.items()
            ]
        }
    
    @app.get("/api/scans/{scan_id}")
    async def get_scan(scan_id: str):
        """Get scan details."""
        if scan_id not in scans_store:
            return JSONResponse(
                status_code=404,
                content={"error": "Scan not found"}
            )
        return scans_store[scan_id]
    
    @app.get("/api/scans/{scan_id}/clusters")
    async def get_clusters(scan_id: str):
        """Get scan clusters."""
        if scan_id not in scans_store:
            return JSONResponse(
                status_code=404,
                content={"error": "Scan not found"}
            )
        return {"clusters": scans_store[scan_id].get("clusters", [])}
    
    @app.get("/api/scans/{scan_id}/transactions")
    async def get_transactions(scan_id: str):
        """Get scan transactions."""
        if scan_id not in scans_store:
            return JSONResponse(
                status_code=404,
                content={"error": "Scan not found"}
            )
        return {"transactions": scans_store[scan_id].get("transactions", [])}
    
    @app.get("/api/dashboard/metrics")
    async def get_metrics():
        """Get dashboard metrics."""
        total_endpoints = sum(
            s.get("discovered_endpoints", 0) 
            for s in scans_store.values()
        )
        total_clusters = sum(
            len(s.get("clusters", [])) 
            for s in scans_store.values()
        )
        
        return {
            "active_scans": 0,
            "total_scans": len(scans_store),
            "total_endpoints": total_endpoints,
            "total_clusters": total_clusters,
            "requests_per_second": 0.0,
            "recent_transactions": [],
        }
    
    @app.get("/api/dashboard/graph")
    async def get_graph():
        """Get graph data for visualization."""
        nodes = []
        links = []
        
        for scan_id, scan in scans_store.items():
            for cluster in scan.get("clusters", []):
                node_id = f"{scan_id}:{cluster.get('pattern')}"
                nodes.append({
                    "id": node_id,
                    "type": "cluster",
                    "pattern": cluster.get("pattern"),
                    "risk": cluster.get("risk_level", "public"),
                    "confidence": cluster.get("confidence_score", 0),
                })
        
        return {"nodes": nodes, "links": links}
    
    # WebSocket for real-time updates
    @app.websocket("/ws")
    async def websocket_endpoint(websocket: WebSocket):
        await websocket.accept()
        try:
            while True:
                data = await websocket.receive_text()
                # Echo back for now
                await websocket.send_json({
                    "type": "pong",
                    "timestamp": datetime.now().isoformat(),
                })
        except WebSocketDisconnect:
            pass
    
    return app


def launch_web_server(scan_data: Optional[Dict[str, Any]] = None, port: int = 8080):
    """Launch the web dashboard server."""
    
    app = create_standalone_app(scan_data)
    
    # Try to mount static files
    frontend_path = get_frontend_path()
    
    if frontend_path.exists():
        # Mount the static files
        app.mount("/", StaticFiles(directory=str(frontend_path), html=True), name="static")
    else:
        # Provide a fallback HTML page
        @app.get("/", response_class=HTMLResponse)
        async def root():
            return """
            <!DOCTYPE html>
            <html>
            <head>
                <title>xrAPI Dashboard</title>
                <style>
                    body { font-family: system-ui, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
                    h1 { color: #238636; }
                    .info { background: #f6f8fa; padding: 20px; border-radius: 8px; margin: 20px 0; }
                    code { background: #eee; padding: 2px 6px; border-radius: 3px; }
                </style>
            </head>
            <body>
                <h1>xrAPI Dashboard</h1>
                <div class="info">
                    <p><strong>Frontend not found.</strong></p>
                    <p>The dashboard frontend files are not installed.</p>
                    <p>To install the full dashboard, run:</p>
                    <code>pip install xrapi[web]</code>
                </div>
                <p>API endpoints are available at <code>/api/</code></p>
            </body>
            </html>
            """
    
    print(f"Starting xrAPI Dashboard on http://localhost:{port}")
    print("Press Ctrl+C to stop")
    
    uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning")


def launch_web():
    """Entry point for xrapi-web command."""
    import argparse
    
    parser = argparse.ArgumentParser(description="xrAPI Web Dashboard")
    parser.add_argument("--port", "-p", type=int, default=8080, help="Port to run on")
    parser.add_argument("--no-browser", action="store_true", help="Don't open browser")
    parser.add_argument("--scan", "-s", help="Load specific scan by ID")
    
    args = parser.parse_args()
    
    scan_data = None
    if args.scan:
        # Try to load scan from local storage
        from xrapi.cli.standalone import load_local_scan
        scan_data = load_local_scan(args.scan)
    
    if not args.no_browser:
        import threading
        import time
        
        def open_browser():
            time.sleep(1.5)
            webbrowser.open(f"http://localhost:{args.port}")
        
        threading.Thread(target=open_browser, daemon=True).start()
    
    launch_web_server(scan_data, port=args.port)


if __name__ == "__main__":
    launch_web()
