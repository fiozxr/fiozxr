#!/usr/bin/env python3
"""
xrAPI Command Line Interface
Main entry point - delegates to standalone CLI.
"""

from xrapi.cli.standalone import main

if __name__ == "__main__":
    main()
