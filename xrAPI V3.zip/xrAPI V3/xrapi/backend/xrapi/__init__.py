"""
xrAPI - Advanced API Endpoint Discovery & Security Analysis Platform

A high-performance, asynchronous API endpoint discovery tool designed for
security professionals, penetration testers, and DevSecOps engineers.

Repository: https://github.com/fiozxr/xrapi
License: GNU General Public License v3.0

Example:
    >>> from xrapi import AsyncScanner, ScanConfig
    >>> import asyncio
    >>> 
    >>> async def main():
    ...     config = ScanConfig(target_url="https://api.example.com")
    ...     scanner = AsyncScanner(config)
    ...     results = await scanner.scan()
    ...     print(f"Found {results['clusters']} clusters")
    >>> 
    >>> asyncio.run(main())

Legal Notice:
    This tool is intended for authorized security testing only. Users are
    solely responsible for ensuring their use complies with all applicable laws.
    See LICENSE for full terms of use.
    
    Remember: With great power comes great responsibility.
    Use xrAPI ethically, legally, and responsibly.
"""

__version__ = "1.0.0"
__author__ = "fiozxr"
__license__ = "GPL-3.0"
__copyright__ = "Copyright 2024 fiozxr"
__repository__ = "https://github.com/fiozxr/xrapi"

from xrapi.core.scanner import (
    AsyncScanner,
    EndpointCluster,
    EndpointRisk,
    HTTPTransaction,
    ParameterType,
    ResponseFingerprint,
    ScanConfig,
)

__all__ = [
    "AsyncScanner",
    "EndpointCluster",
    "EndpointRisk",
    "HTTPTransaction",
    "ParameterType",
    "ResponseFingerprint",
    "ScanConfig",
    "__version__",
    "__author__",
    "__repository__",
]
