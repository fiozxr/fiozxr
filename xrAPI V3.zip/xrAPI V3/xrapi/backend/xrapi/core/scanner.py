"""
xrAPI Core Scanning Engine
Async HTTP/2 scanning with adaptive rate limiting and intelligent response classification.
"""

import asyncio
import hashlib
import json
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, AsyncGenerator, Callable, Dict, List, Optional, Set, Tuple
from urllib.parse import urljoin, urlparse

import httpx
import structlog
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

logger = structlog.get_logger()


class ParameterType(Enum):
    """Classification of path parameter types."""
    STATIC = "static"
    NUMERIC = "numeric"
    UUID = "uuid"
    STRING = "string"
    HASH = "hash"


class EndpointRisk(Enum):
    """Risk classification for endpoints."""
    PUBLIC = "public"           # No authentication required
    AUTHENTICATED = "authenticated"  # Requires valid credentials
    PRIVILEGED = "privileged"   # Shows behavioral differences across auth states
    SENSITIVE = "sensitive"     # Potential security concern


@dataclass
class ResponseFingerprint:
    """Structured response fingerprint for classification."""
    status_code: int
    content_type: str
    content_length: int
    headers: Dict[str, str] = field(default_factory=dict)
    body_hash: str = ""
    body_entropy: float = 0.0
    structure_signature: str = ""
    error_page: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "status_code": self.status_code,
            "content_type": self.content_type,
            "content_length": self.content_length,
            "body_hash": self.body_hash,
            "body_entropy": self.body_entropy,
            "structure_signature": self.structure_signature,
            "error_page": self.error_page,
        }


@dataclass
class HTTPTransaction:
    """Complete HTTP request/response pair."""
    timestamp: float
    method: str
    url: str
    headers: Dict[str, str]
    request_body: Optional[str]
    response: Optional[ResponseFingerprint]
    response_body: Optional[str]
    response_time_ms: float
    error: Optional[str] = None
    auth_state: Optional[str] = None  # "unauthenticated", "authenticated", "admin", etc.
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "method": self.method,
            "url": self.url,
            "headers": self.headers,
            "request_body": self.request_body,
            "response": self.response.to_dict() if self.response else None,
            "response_body": self.response_body,
            "response_time_ms": self.response_time_ms,
            "error": self.error,
            "auth_state": self.auth_state,
        }


@dataclass
class EndpointCluster:
    """Cluster of semantically similar endpoints."""
    pattern: str  # /api/v1/users/{id}
    observed_paths: List[str] = field(default_factory=list)
    parameter_samples: Dict[int, List[str]] = field(default_factory=dict)
    transactions: List[HTTPTransaction] = field(default_factory=list)
    parameter_types: List[ParameterType] = field(default_factory=list)
    confidence_score: float = 0.0
    risk_level: EndpointRisk = EndpointRisk.PUBLIC
    auth_behavior_diff: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "pattern": self.pattern,
            "observed_paths": self.observed_paths,
            "parameter_samples": self.parameter_samples,
            "confidence_score": self.confidence_score,
            "risk_level": self.risk_level.value,
            "auth_behavior_diff": self.auth_behavior_diff,
            "transaction_count": len(self.transactions),
        }


@dataclass
class ScanConfig:
    """Configuration for a scan session."""
    target_url: str
    wordlist_paths: List[str] = field(default_factory=list)
    extensions: List[str] = field(default_factory=lambda: ["", ".json", ".xml", ".api"])
    headers: Dict[str, str] = field(default_factory=dict)
    cookies: Dict[str, str] = field(default_factory=dict)
    auth_tokens: Dict[str, str] = field(default_factory=dict)
    proxy: Optional[str] = None
    timeout: int = 30
    max_retries: int = 3
    concurrency: int = 50
    rate_limit: float = 0.0  # Requests per second, 0 = unlimited
    follow_redirects: bool = True
    verify_ssl: bool = True
    http2: bool = True
    user_agent: str = "xrAPI/1.0 Security Scanner"
    
    # Discovery options
    recursive: bool = True
    max_depth: int = 3
    parameter_fuzzing: bool = True
    method_discovery: bool = True
    
    # Filtering
    hide_codes: List[int] = field(default_factory=list)
    show_only_codes: List[int] = field(default_factory=list)
    min_response_size: int = 0
    max_response_size: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "target_url": self.target_url,
            "wordlist_paths": self.wordlist_paths,
            "extensions": self.extensions,
            "headers": self.headers,
            "timeout": self.timeout,
            "concurrency": self.concurrency,
            "rate_limit": self.rate_limit,
            "http2": self.http2,
            "recursive": self.recursive,
            "max_depth": self.max_depth,
        }


class ResponseClassifier:
    """Intelligent response classification and fingerprinting."""
    
    # Common error page signatures
    ERROR_SIGNATURES = [
        b"<title>404 Not Found</title>",
        b"<title>403 Forbidden</title>",
        b"nginx/",
        b"Apache/",
        b"IIS",
        b"<h1>Not Found</h1>",
        b"<h1>Forbidden</h1>",
        b'"error":',
        b'"message":',
    ]
    
    def __init__(self):
        self.known_fingerprints: Dict[str, ResponseFingerprint] = {}
        
    def calculate_entropy(self, data: bytes) -> float:
        """Calculate Shannon entropy of data."""
        if not data:
            return 0.0
        
        entropy = 0.0
        length = len(data)
        
        for byte in range(256):
            count = data.count(byte)
            if count > 0:
                p = count / length
                entropy -= p * (p.bit_length() - 1)
        
        return entropy
    
    def extract_structure(self, body: str) -> str:
        """Extract structural signature from response body."""
        # Remove values, keep structure
        # JSON: {"key": "value"} -> {"key": "<str>"}
        # HTML: <tag attr="value"> -> <tag attr>
        
        if not body:
            return ""
        
        # Try JSON structure extraction
        try:
            data = json.loads(body)
            return self._extract_json_structure(data)
        except json.JSONDecodeError:
            pass
        
        # HTML structure extraction
        if body.strip().startswith('<'):
            return self._extract_html_structure(body)
        
        return "text"
    
    def _extract_json_structure(self, data: Any, depth: int = 0) -> str:
        """Recursively extract JSON structure."""
        if depth > 10:
            return "<deep>"
        
        if isinstance(data, dict):
            items = []
            for k, v in sorted(data.items()):
                items.append(f'"{k}":{self._extract_json_structure(v, depth+1)}')
            return "{" + ",".join(items) + "}"
        elif isinstance(data, list):
            if data:
                return f'[{self._extract_json_structure(data[0], depth+1)}]'
            return "[]"
        elif isinstance(data, str):
            return "<str>"
        elif isinstance(data, (int, float)):
            return "<num>"
        elif isinstance(data, bool):
            return "<bool>"
        else:
            return "<null>"
    
    def _extract_html_structure(self, html: str) -> str:
        """Extract HTML tag structure."""
        # Simple tag extraction
        tags = re.findall(r'<(\w+)[^>]*>', html)
        return ">".join(tags[:20])  # Limit depth
    
    def is_error_page(self, body: bytes) -> bool:
        """Detect if response is a generic error page."""
        body_lower = body.lower()
        for sig in self.ERROR_SIGNATURES:
            if sig in body_lower:
                return True
        return False
    
    def classify(self, response: httpx.Response) -> ResponseFingerprint:
        """Create fingerprint from HTTP response."""
        body = response.content
        body_str = body.decode('utf-8', errors='ignore')
        
        # Calculate body hash
        body_hash = hashlib.md5(body).hexdigest()
        
        # Calculate entropy
        entropy = self.calculate_entropy(body)
        
        # Extract structure
        structure = self.extract_structure(body_str)
        
        # Check if error page
        is_error = self.is_error_page(body)
        
        return ResponseFingerprint(
            status_code=response.status_code,
            content_type=response.headers.get('content-type', ''),
            content_length=len(body),
            headers=dict(response.headers),
            body_hash=body_hash,
            body_entropy=entropy,
            structure_signature=structure,
            error_page=is_error,
        )
    
    def are_similar(self, fp1: ResponseFingerprint, fp2: ResponseFingerprint) -> bool:
        """Determine if two fingerprints represent similar responses."""
        # Same status code
        if fp1.status_code != fp2.status_code:
            return False
        
        # Same content type (roughly)
        ct1 = fp1.content_type.split(';')[0].strip()
        ct2 = fp2.content_type.split(';')[0].strip()
        if ct1 != ct2:
            return False
        
        # Same body hash = identical
        if fp1.body_hash == fp2.body_hash:
            return True
        
        # Similar structure
        if fp1.structure_signature and fp1.structure_signature == fp2.structure_signature:
            return True
        
        # Similar size (within 10%)
        if fp1.content_length > 0:
            size_diff = abs(fp1.content_length - fp2.content_length) / fp1.content_length
            if size_diff < 0.1:
                return True
        
        return False


class AdaptiveRateLimiter:
    """Adaptive rate limiter that adjusts to target responsiveness."""
    
    def __init__(self, initial_rate: float = 100.0, min_rate: float = 1.0, max_rate: float = 500.0):
        self.current_rate = initial_rate
        self.min_rate = min_rate
        self.max_rate = max_rate
        self.request_times: List[float] = []
        self.error_count = 0
        self.success_count = 0
        self.last_adjustment = time.time()
        self.lock = asyncio.Lock()
        
    async def acquire(self):
        """Acquire permission to make a request."""
        async with self.lock:
            now = time.time()
            interval = 1.0 / self.current_rate
            
            # Clean old request times (keep last 100)
            cutoff = now - 1.0
            self.request_times = [t for t in self.request_times if t > cutoff]
            
            # Check if we need to wait
            if self.request_times:
                last_request = self.request_times[-1]
                elapsed = now - last_request
                if elapsed < interval:
                    wait_time = interval - elapsed
                    await asyncio.sleep(wait_time)
            
            self.request_times.append(time.time())
    
    def report_success(self, response_time: float):
        """Report successful request."""
        self.success_count += 1
        
        # Periodically adjust rate
        if time.time() - self.last_adjustment > 5.0:
            self._adjust_rate()
    
    def report_error(self, error_type: str):
        """Report request error."""
        self.error_count += 1
        
        # Back off on errors
        if error_type in ("timeout", "connection"):
            self.current_rate = max(self.min_rate, self.current_rate * 0.5)
            logger.warning("rate_limiter.backoff", rate=self.current_rate, error=error_type)
    
    def _adjust_rate(self):
        """Adjust rate based on performance."""
        total = self.success_count + self.error_count
        if total == 0:
            return
        
        error_rate = self.error_count / total
        
        if error_rate < 0.01:
            # Low error rate, can increase
            self.current_rate = min(self.max_rate, self.current_rate * 1.2)
        elif error_rate > 0.1:
            # High error rate, decrease
            self.current_rate = max(self.min_rate, self.current_rate * 0.8)
        
        logger.info("rate_limiter.adjust", rate=self.current_rate, error_rate=error_rate)
        
        # Reset counters
        self.success_count = 0
        self.error_count = 0
        self.last_adjustment = time.time()


class EndpointClustering:
    """Semantic endpoint clustering and pattern recognition."""
    
    UUID_PATTERN = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$', re.I)
    NUMERIC_PATTERN = re.compile(r'^\d+$')
    HASH_PATTERN = re.compile(r'^[0-9a-f]{32,64}$', re.I)
    
    def __init__(self):
        self.clusters: Dict[str, EndpointCluster] = {}
        self.path_index: Dict[str, Set[str]] = {}  # pattern -> set of paths
        
    def classify_segment(self, segment: str) -> ParameterType:
        """Classify a path segment."""
        if not segment:
            return ParameterType.STATIC
        
        if self.UUID_PATTERN.match(segment):
            return ParameterType.UUID
        
        if self.NUMERIC_PATTERN.match(segment):
            return ParameterType.NUMERIC
        
        if self.HASH_PATTERN.match(segment):
            return ParameterType.HASH
        
        # Check if it looks like a parameter (contains special chars or mixed case)
        if re.search(r'[^a-zA-Z0-9_-]', segment):
            return ParameterType.STRING
        
        return ParameterType.STATIC
    
    def tokenize_path(self, path: str) -> List[Tuple[str, ParameterType]]:
        """Tokenize a path into segments with types."""
        segments = path.strip('/').split('/')
        return [(seg, self.classify_segment(seg)) for seg in segments if seg]
    
    def create_pattern(self, tokens: List[Tuple[str, ParameterType]]) -> str:
        """Create pattern from tokens."""
        pattern_segments = []
        for seg, seg_type in tokens:
            if seg_type == ParameterType.STATIC:
                pattern_segments.append(seg)
            elif seg_type == ParameterType.NUMERIC:
                pattern_segments.append("{id}")
            elif seg_type == ParameterType.UUID:
                pattern_segments.append("{uuid}")
            elif seg_type == ParameterType.HASH:
                pattern_segments.append("{hash}")
            else:
                pattern_segments.append("{str}")
        
        return "/" + "/".join(pattern_segments)
    
    def add_endpoint(self, path: str, transaction: HTTPTransaction) -> EndpointCluster:
        """Add an endpoint to clustering."""
        tokens = self.tokenize_path(path)
        pattern = self.create_pattern(tokens)
        
        if pattern not in self.clusters:
            self.clusters[pattern] = EndpointCluster(
                pattern=pattern,
                parameter_types=[t[1] for t in tokens],
            )
            self.path_index[pattern] = set()
        
        cluster = self.clusters[pattern]
        
        if path not in self.path_index[pattern]:
            cluster.observed_paths.append(path)
            self.path_index[pattern].add(path)
            
            # Collect parameter samples
            for i, (seg, seg_type) in enumerate(tokens):
                if seg_type != ParameterType.STATIC:
                    if i not in cluster.parameter_samples:
                        cluster.parameter_samples[i] = []
                    if seg not in cluster.parameter_samples[i]:
                        cluster.parameter_samples[i].append(seg)
        
        cluster.transactions.append(transaction)
        
        # Update confidence score
        cluster.confidence_score = self._calculate_confidence(cluster)
        
        return cluster
    
    def _calculate_confidence(self, cluster: EndpointCluster) -> float:
        """Calculate confidence score for a cluster."""
        if len(cluster.observed_paths) < 2:
            return 0.3
        
        # More samples = higher confidence
        sample_confidence = min(1.0, len(cluster.observed_paths) / 10)
        
        # Consistent parameter types = higher confidence
        type_consistency = 1.0
        for samples in cluster.parameter_samples.values():
            if len(samples) >= 2:
                # Check if all samples are same type
                types = set()
                for s in samples:
                    types.add(self.classify_segment(s))
                if len(types) > 1:
                    type_consistency *= 0.8
        
        return sample_confidence * type_consistency
    
    def get_clusters(self) -> List[EndpointCluster]:
        """Get all clusters sorted by confidence."""
        return sorted(self.clusters.values(), key=lambda c: c.confidence_score, reverse=True)
    
    def analyze_auth_behavior(self, auth_states: List[str]):
        """Analyze clusters for authentication behavior differences."""
        for cluster in self.clusters.values():
            # Group transactions by auth state
            by_auth: Dict[str, List[HTTPTransaction]] = {}
            for tx in cluster.transactions:
                state = tx.auth_state or "unauthenticated"
                if state not in by_auth:
                    by_auth[state] = []
                by_auth[state].append(tx)
            
            # Compare response patterns across auth states
            if len(by_auth) > 1:
                status_codes = {}
                for state, txs in by_auth.items():
                    codes = set(tx.response.status_code for tx in txs if tx.response)
                    status_codes[state] = codes
                
                # If different auth states get different status codes, flag it
                code_sets = list(status_codes.values())
                if len(code_sets) >= 2:
                    if code_sets[0] != code_sets[1]:
                        cluster.auth_behavior_diff = True
                        cluster.risk_level = EndpointRisk.PRIVILEGED


class AsyncScanner:
    """High-performance async API scanner."""
    
    def __init__(self, config: ScanConfig):
        self.config = config
        self.classifier = ResponseClassifier()
        self.clustering = EndpointClustering()
        self.rate_limiter = AdaptiveRateLimiter(
            initial_rate=config.rate_limit if config.rate_limit > 0 else 100.0
        )
        
        self.transactions: List[HTTPTransaction] = []
        self.discovered_endpoints: Set[str] = set()
        self.active = False
        self.stats = {
            "requests": 0,
            "responses": 0,
            "errors": 0,
            "start_time": 0.0,
        }
        
        # Callbacks for real-time updates
        self.on_transaction: Optional[Callable[[HTTPTransaction], None]] = None
        self.on_cluster: Optional[Callable[[EndpointCluster], None]] = None
        
    async def _create_client(self) -> httpx.AsyncClient:
        """Create configured HTTP client."""
        headers = {
            "User-Agent": self.config.user_agent,
            **self.config.headers,
        }
        
        return httpx.AsyncClient(
            headers=headers,
            cookies=self.config.cookies,
            timeout=httpx.Timeout(self.config.timeout),
            follow_redirects=self.config.follow_redirects,
            verify=self.config.verify_ssl,
            http2=self.config.http2,
            proxy=self.config.proxy,
        )
    
    @retry(
        retry=retry_if_exception_type((httpx.TimeoutException, httpx.ConnectError)),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
    )
    async def _request(
        self,
        client: httpx.AsyncClient,
        method: str,
        url: str,
        auth_state: Optional[str] = None,
    ) -> HTTPTransaction:
        """Make a single HTTP request with retry logic."""
        await self.rate_limiter.acquire()
        
        start_time = time.time()
        timestamp = start_time
        
        try:
            response = await client.request(method, url)
            response_time = (time.time() - start_time) * 1000
            
            # Classify response
            fingerprint = self.classifier.classify(response)
            
            # Store body for analysis (limit size)
            body = response.text[:100000]  # Max 100KB
            
            tx = HTTPTransaction(
                timestamp=timestamp,
                method=method,
                url=url,
                headers=dict(response.request.headers),
                request_body=None,
                response=fingerprint,
                response_body=body,
                response_time_ms=response_time,
                auth_state=auth_state,
            )
            
            self.rate_limiter.report_success(response_time)
            self.stats["responses"] += 1
            
            return tx
            
        except httpx.TimeoutException as e:
            self.rate_limiter.report_error("timeout")
            self.stats["errors"] += 1
            return HTTPTransaction(
                timestamp=timestamp,
                method=method,
                url=url,
                headers={},
                request_body=None,
                response=None,
                response_body=None,
                response_time_ms=(time.time() - start_time) * 1000,
                error=f"Timeout: {str(e)}",
                auth_state=auth_state,
            )
            
        except httpx.ConnectError as e:
            self.rate_limiter.report_error("connection")
            self.stats["errors"] += 1
            return HTTPTransaction(
                timestamp=timestamp,
                method=method,
                url=url,
                headers={},
                request_body=None,
                response=None,
                response_body=None,
                response_time_ms=(time.time() - start_time) * 1000,
                error=f"Connection error: {str(e)}",
                auth_state=auth_state,
            )
            
        except Exception as e:
            self.stats["errors"] += 1
            return HTTPTransaction(
                timestamp=timestamp,
                method=method,
                url=url,
                headers={},
                request_body=None,
                response=None,
                response_body=None,
                response_time_ms=(time.time() - start_time) * 1000,
                error=str(e),
                auth_state=auth_state,
            )
    
    async def _scan_path(
        self,
        client: httpx.AsyncClient,
        base_url: str,
        path: str,
        auth_state: Optional[str] = None,
    ) -> Optional[HTTPTransaction]:
        """Scan a single path."""
        url = urljoin(base_url, path)
        
        # Skip if already discovered
        if url in self.discovered_endpoints:
            return None
        
        self.discovered_endpoints.add(url)
        self.stats["requests"] += 1
        
        # Make request
        tx = await self._request(client, "GET", url, auth_state)
        
        # Store transaction
        self.transactions.append(tx)
        
        # Update clustering
        parsed = urlparse(url)
        cluster = self.clustering.add_endpoint(parsed.path, tx)
        
        # Notify callbacks
        if self.on_transaction:
            await asyncio.get_event_loop().run_in_executor(None, self.on_transaction, tx)
        if self.on_cluster:
            await asyncio.get_event_loop().run_in_executor(None, self.on_cluster, cluster)
        
        return tx
    
    async def _scan_with_wordlist(
        self,
        client: httpx.AsyncClient,
        base_url: str,
        wordlist: List[str],
        auth_state: Optional[str] = None,
    ) -> AsyncGenerator[HTTPTransaction, None]:
        """Scan using a wordlist with controlled concurrency."""
        semaphore = asyncio.Semaphore(self.config.concurrency)
        
        async def scan_word(word: str):
            async with semaphore:
                for ext in self.config.extensions:
                    path = word + ext
                    tx = await self._scan_path(client, base_url, path, auth_state)
                    if tx:
                        yield tx
        
        tasks = []
        for word in wordlist:
            task = asyncio.create_task(self._scan_word_task(client, base_url, word, auth_state))
            tasks.append(task)
        
        for completed in asyncio.as_completed(tasks):
            tx = await completed
            if tx:
                yield tx
    
    async def _scan_word_task(
        self,
        client: httpx.AsyncClient,
        base_url: str,
        word: str,
        auth_state: Optional[str] = None,
    ) -> Optional[HTTPTransaction]:
        """Scan a single word with all extensions."""
        for ext in self.config.extensions:
            path = word + ext
            tx = await self._scan_path(client, base_url, path, auth_state)
            if tx:
                return tx
        return None
    
    async def scan(
        self,
        wordlists: Optional[List[List[str]]] = None,
        on_progress: Optional[Callable[[Dict], None]] = None,
    ) -> Dict[str, Any]:
        """Run complete scan."""
        self.active = True
        self.stats["start_time"] = time.time()
        
        logger.info("scanner.start", target=self.config.target_url)
        
        async with await self._create_client() as client:
            # Default wordlist if none provided
            if not wordlists:
                wordlists = [self._load_default_wordlist()]
            
            # Scan with each auth state
            auth_states = ["unauthenticated"]
            if self.config.auth_tokens:
                auth_states.extend(self.config.auth_tokens.keys())
            
            for auth_state in auth_states:
                # Configure auth for this state
                if auth_state != "unauthenticated":
                    token = self.config.auth_tokens.get(auth_state, "")
                    client.headers["Authorization"] = f"Bearer {token}"
                
                # Scan all wordlists
                for wordlist in wordlists:
                    if not self.active:
                        break
                    
                    async for tx in self._scan_with_wordlist(
                        client, self.config.target_url, wordlist, auth_state
                    ):
                        if on_progress:
                            on_progress(self._get_progress())
            
            # Analyze auth behavior differences
            self.clustering.analyze_auth_behavior(auth_states)
        
        self.active = False
        duration = time.time() - self.stats["start_time"]
        
        logger.info("scanner.complete", duration=duration, **self.stats)
        
        return {
            "duration_seconds": duration,
            "transactions": len(self.transactions),
            "clusters": len(self.clustering.clusters),
            "discovered_endpoints": len(self.discovered_endpoints),
            "stats": self.stats,
        }
    
    def _get_progress(self) -> Dict[str, Any]:
        """Get current scan progress."""
        duration = time.time() - self.stats["start_time"]
        rps = self.stats["requests"] / duration if duration > 0 else 0
        
        return {
            "requests": self.stats["requests"],
            "responses": self.stats["responses"],
            "errors": self.stats["errors"],
            "duration": duration,
            "requests_per_second": rps,
            "clusters": len(self.clustering.clusters),
            "endpoints": len(self.discovered_endpoints),
        }
    
    def _load_default_wordlist(self) -> List[str]:
        """Load default wordlist."""
        # Common API paths
        return [
            "api", "v1", "v2", "v3", "version", "versions",
            "users", "user", "accounts", "account",
            "auth", "login", "logout", "register", "signup",
            "admin", "dashboard", "panel", "manage",
            "products", "product", "items", "item",
            "orders", "order", "cart", "checkout",
            "search", "find", "query",
            "health", "status", "ping", "ready",
            "docs", "documentation", "swagger", "openapi",
            "graphql", "gql", "subscriptions",
            "webhooks", "hooks", "callbacks",
            "internal", "private", "debug", "test",
            "config", "configuration", "settings",
            "files", "uploads", "media", "assets",
            "notifications", "messages", "emails",
            "reports", "analytics", "metrics",
            "roles", "permissions", "groups",
            "tokens", "sessions", "keys",
            "payments", "billing", "invoices",
            "subscriptions", "plans", "pricing",
        ]
    
    def stop(self):
        """Stop the scan."""
        self.active = False
        logger.info("scanner.stop")
    
    def get_results(self) -> Dict[str, Any]:
        """Get scan results."""
        return {
            "transactions": [tx.to_dict() for tx in self.transactions],
            "clusters": [c.to_dict() for c in self.clustering.get_clusters()],
            "stats": self.stats,
        }
