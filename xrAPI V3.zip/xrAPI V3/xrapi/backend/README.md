# xrAPI - Advanced API Endpoint Discovery & Security Analysis Platform

xrAPI is a high-performance, asynchronous API endpoint discovery and security analysis tool designed for security professionals, penetration testers, and DevSecOps engineers.

## Features

- **Async HTTP/2 Scanning**: High-concurrency scanning with adaptive rate limiting
- **Intelligent Endpoint Clustering**: Semantic path analysis and pattern recognition
- **Response Classification**: Multi-factor fingerprinting beyond status codes
- **State-Aware Scanning**: Parallel authenticated/unauthenticated probing
- **Real-time Dashboard**: Web interface with live updates via WebSocket
- **Comprehensive Logging**: Structured logs with audit trail
- **Multiple Import Formats**: Burp Suite, OWASP ZAP, HAR, OpenAPI, Postman
- **Export Options**: JSON, CSV, OpenAPI specification

## Installation

```bash
pip install -r requirements.txt
```

## Quick Start

### CLI Usage

```bash
# Basic scan
xrapi scan https://api.example.com

# With custom wordlist
xrapi scan https://api.example.com -w wordlist.txt

# With authentication
xrapi scan https://api.example.com -a "Bearer token123"

# Export results
xrapi scan https://api.example.com -o results.json
```

### Web Server

```bash
xrapi server --host 0.0.0.0 --port 8000
```

### API Usage

```bash
# Create and start a scan
curl -X POST http://localhost:8000/api/scans \
  -H "Content-Type: application/json" \
  -d '{"target_url": "https://api.example.com"}'

# Get scan progress
curl http://localhost:8000/api/scans/{scan_id}/progress

# Export results
curl http://localhost:8000/api/scans/{scan_id}/export?format=openapi
```

## Architecture

xrAPI is built on three fundamental principles:

1. **Speed without destruction**: Adaptive rate limiting that responds to target behavior
2. **Intelligence over enumeration**: Semantic clustering treats endpoints as a graph
3. **Observability by design**: Every operation is logged and traceable

## License

MIT License
