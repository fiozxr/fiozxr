"""
xrAPI - Advanced API Endpoint Discovery & Security Analysis Platform
"""

from setuptools import find_packages, setup

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="xrapi",
    version="1.0.0",
    author="xrAPI Security",
    author_email="security@xrapi.io",
    description="Advanced API Endpoint Discovery & Security Analysis Platform",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/xrapi/xrapi",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Information Technology",
        "Topic :: Security",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.11",
    install_requires=requirements,
    entry_points={
        "console_scripts": [
            "xrapi=xrapi.cli.main:main",
        ],
    },
    include_package_data=True,
    package_data={
        "xrapi": ["wordlists/*.txt"],
    },
)
