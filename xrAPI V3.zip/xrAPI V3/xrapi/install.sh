#!/bin/bash
# xrAPI Installation Script
# Supports: Linux, macOS, Windows (WSL/Git Bash)
# Repository: https://github.com/fiozxr/xrapi

set -e

echo "========================================"
echo "xrAPI Installation Script"
echo "https://github.com/fiozxr/xrapi"
echo "========================================"
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Check Python version
check_python() {
    if command -v python3 &> /dev/null; then
        PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
        PYTHON_MAJOR=$(echo $PYTHON_VERSION | cut -d. -f1)
        PYTHON_MINOR=$(echo $PYTHON_VERSION | cut -d. -f2)
        
        if [ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -ge 11 ]; then
            echo -e "${GREEN}✓ Python $PYTHON_VERSION found${NC}"
            return 0
        else
            echo -e "${RED}✗ Python 3.11+ required (found $PYTHON_VERSION)${NC}"
            echo -e "${YELLOW}Please upgrade Python: https://www.python.org/downloads/${NC}"
            return 1
        fi
    else
        echo -e "${RED}✗ Python 3 not found${NC}"
        echo -e "${YELLOW}Please install Python 3.11+: https://www.python.org/downloads/${NC}"
        return 1
    fi
}

# Check pip
check_pip() {
    if command -v pip3 &> /dev/null; then
        echo -e "${GREEN}✓ pip found${NC}"
        return 0
    else
        echo -e "${RED}✗ pip not found${NC}"
        return 1
    fi
}

# Check git
check_git() {
    if command -v git &> /dev/null; then
        echo -e "${GREEN}✓ git found${NC}"
        return 0
    else
        echo -e "${YELLOW}⚠ git not found (optional, for development)${NC}"
        return 0
    fi
}

# Install xrAPI from source
install_from_source() {
    echo ""
    echo -e "${BLUE}Installing xrAPI from source...${NC}"
    
    INSTALL_MODE="${1:-basic}"
    
    # Check if we're in the xrAPI directory
    if [ -f "pyproject.toml" ] && grep -q "xrapi" pyproject.toml 2>/dev/null; then
        echo -e "${BLUE}Found xrAPI source directory${NC}"
    else
        # Clone repository
        echo -e "${BLUE}Cloning xrAPI repository...${NC}"
        git clone https://github.com/fiozxr/xrapi.git /tmp/xrapi
        cd /tmp/xrapi
    fi
    
    # Create virtual environment if not exists
    if [ ! -d "venv" ]; then
        echo -e "${BLUE}Creating virtual environment...${NC}"
        python3 -m venv venv
    fi
    
    # Activate virtual environment
    source venv/bin/activate
    
    # Upgrade pip
    pip install --upgrade pip
    
    # Install based on mode
    case $INSTALL_MODE in
        basic)
            echo -e "${BLUE}Installing xrAPI (basic mode)...${NC}"
            pip install -e .
            ;;
        web)
            echo -e "${BLUE}Installing xrAPI with web dashboard...${NC}"
            pip install -e ".[web]"
            ;;
        dev)
            echo -e "${BLUE}Installing xrAPI with development tools...${NC}"
            pip install -e ".[dev]"
            ;;
        full)
            echo -e "${BLUE}Installing xrAPI with all features...${NC}"
            pip install -e ".[web,dev]"
            ;;
        *)
            echo -e "${RED}Unknown install mode: $INSTALL_MODE${NC}"
            echo "Valid modes: basic, web, dev, full"
            exit 1
            ;;
    esac
    
    if [ $? -eq 0 ]; then
        echo ""
        echo -e "${GREEN}✓ xrAPI installed successfully!${NC}"
    else
        echo ""
        echo -e "${RED}✗ Installation failed${NC}"
        exit 1
    fi
}

# Verify installation
verify_install() {
    echo ""
    echo -e "${BLUE}Verifying installation...${NC}"
    
    if command -v xrapi &> /dev/null; then
        VERSION=$(xrapi --version 2>&1)
        echo -e "${GREEN}✓ xrAPI installed: $VERSION${NC}"
        
        # Create data directory
        mkdir -p ~/.xrapi/{scans,logs,wordlists,exports}
        echo -e "${GREEN}✓ Data directory created at ~/.xrapi${NC}"
        
        return 0
    else
        echo -e "${RED}✗ xrAPI command not found${NC}"
        echo -e "${YELLOW}Try adding the virtual environment to your PATH:${NC}"
        echo "  export PATH=\"\$HOME/.local/bin:\$PATH\""
        return 1
    fi
}

# Print usage
print_usage() {
    echo ""
    echo "Usage: $0 [MODE]"
    echo ""
    echo "Installation Modes:"
    echo "  basic   - CLI only (default) - minimal dependencies"
    echo "  web     - CLI + Web dashboard support"
    echo "  dev     - CLI + Development tools (testing, linting)"
    echo "  full    - Everything (web + dev)"
    echo ""
    echo "Examples:"
    echo "  $0           # Install basic mode"
    echo "  $0 web       # Install with web dashboard"
    echo "  $0 full      # Install everything"
    echo ""
}

# Print banner
print_banner() {
    echo ""
    echo -e "${GREEN}========================================${NC}"
    echo -e "${GREEN}  Installation Complete!${NC}"
    echo -e "${GREEN}========================================${NC}"
    echo ""
    echo -e "${BLUE}Quick Start:${NC}"
    echo "  xrapi --version              # Check version"
    echo "  xrapi scan https://target    # Run a scan"
    echo "  xrapi list                   # List saved scans"
    echo "  xrapi dashboard              # Launch web dashboard"
    echo ""
    echo -e "${BLUE}Documentation:${NC}"
    echo "  https://github.com/fiozxr/xrapi"
    echo ""
    echo -e "${YELLOW}⚠ IMPORTANT: Only scan systems you own or have permission to test!${NC}"
    echo ""
}

# Main
main() {
    # Show help
    if [ "$1" = "-h" ] || [ "$1" = "--help" ]; then
        print_usage
        exit 0
    fi
    
    # Check prerequisites
    echo -e "${BLUE}Checking prerequisites...${NC}"
    check_python || exit 1
    check_pip || exit 1
    check_git
    
    # Install
    install_from_source "$1"
    
    # Verify
    verify_install
    
    # Print success message
    print_banner
}

main "$@"
