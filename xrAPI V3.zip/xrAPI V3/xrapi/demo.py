#!/usr/bin/env python3
"""
xrAPI Demo Script
Demonstrates the core scanning functionality.
"""

import asyncio
import sys
from pathlib import Path

# Add backend to path
sys.path.insert(0, str(Path(__file__).parent / "backend"))

from xrapi.core.scanner import AsyncScanner, ScanConfig
from xrapi.utils.logging import configure_logging


async def demo_scan():
    """Run a demonstration scan."""
    
    configure_logging(log_level="INFO")
    
    print("=" * 60)
    print("xrAPI - Advanced API Endpoint Discovery Demo")
    print("=" * 60)
    print()
    
    # Create scan configuration
    config = ScanConfig(
        target_url="https://httpbin.org",  # Test API
        concurrency=10,
        rate_limit=5.0,  # 5 requests per second
        timeout=10,
        http2=True,
        extensions=["", ".json", ".html"],
    )
    
    print(f"Target: {config.target_url}")
    print(f"Concurrency: {config.concurrency}")
    print(f"Rate Limit: {config.rate_limit} req/s")
    print(f"HTTP/2: {config.http2}")
    print()
    
    # Create scanner
    scanner = AsyncScanner(config)
    
    # Custom wordlist for demo
    wordlist = [
        "get",
        "post", 
        "put",
        "delete",
        "patch",
        "headers",
        "ip",
        "user-agent",
        "cookies",
        "redirect",
        "stream",
        "delay",
        "cache",
        "encoding",
        "gzip",
        "deflate",
        "brotli",
        "bytes",
        "uuid",
        "base64",
        "image",
        "xml",
        "forms",
    ]
    
    print("Starting scan...")
    print("-" * 60)
    
    # Progress callback
    def on_progress(progress):
        print(f"\rRequests: {progress['requests']} | "
              f"RPS: {progress['requests_per_second']:.1f} | "
              f"Clusters: {progress['clusters']}", end="", flush=True)
    
    try:
        # Run scan
        results = await scanner.scan([[wordlist]], on_progress=on_progress)
        
        print()
        print("-" * 60)
        print()
        
        # Display results
        print("SCAN RESULTS")
        print("=" * 60)
        print(f"Duration: {results['duration_seconds']:.2f} seconds")
        print(f"Total Requests: {results['stats']['requests']}")
        print(f"Successful: {results['stats']['responses']}")
        print(f"Errors: {results['stats']['errors']}")
        print(f"Endpoints Discovered: {results['discovered_endpoints']}")
        print(f"Clusters Found: {results['clusters']}")
        print()
        
        # Display clusters
        clusters = scanner.clustering.get_clusters()
        if clusters:
            print("TOP CLUSTERS")
            print("=" * 60)
            for i, cluster in enumerate(clusters[:10], 1):
                print(f"{i}. {cluster.pattern}")
                print(f"   Observed: {len(cluster.observed_paths)} paths")
                print(f"   Confidence: {cluster.confidence_score:.1%}")
                print(f"   Risk: {cluster.risk_level.value}")
                if cluster.parameter_samples:
                    samples = list(cluster.parameter_samples.values())[0][:3]
                    print(f"   Samples: {', '.join(samples)}")
                print()
        
        # Display transactions
        transactions = scanner.transactions
        if transactions:
            print("SAMPLE TRANSACTIONS")
            print("=" * 60)
            for tx in transactions[:5]:
                status = tx.response.status_code if tx.response else "ERR"
                print(f"{tx.method:6} {tx.url[:50]:50} -> {status}")
        
        print()
        print("=" * 60)
        print("Demo completed successfully!")
        print("=" * 60)
        
    except KeyboardInterrupt:
        print("\n\nScan interrupted by user")
        scanner.stop()
    except Exception as e:
        print(f"\n\nError: {e}")
        raise


if __name__ == "__main__":
    try:
        asyncio.run(demo_scan())
    except KeyboardInterrupt:
        print("\nDemo terminated")
        sys.exit(0)
