# xrAPI - Advanced API Endpoint Discovery & Security Analysis Platform

<p align="center">
  <img src="https://img.shields.io/badge/xrAPI-v1.0.0-238636?style=for-the-badge&logo=shield&logoColor=white" alt="xrAPI">
  <br>
  <img src="https://img.shields.io/badge/Python-3.11+-3776AB?style=flat-square&logo=python&logoColor=white" alt="Python">
  <img src="https://img.shields.io/badge/License-GPL%20v3-blue?style=flat-square&logo=gnu" alt="License">
  <img src="https://img.shields.io/badge/Platform-Linux%20%7C%20macOS%20%7C%20Windows-lightgrey?style=flat-square" alt="Platform">
</p>

<p align="center">
  <b>High-performance, asynchronous API endpoint discovery and security analysis tool</b><br>
  For security professionals, penetration testers, and DevSecOps engineers
</p>

---

## ⚠️ LEGAL DISCLAIMER

**BY USING XRAPI, YOU AGREE TO THE FOLLOWING TERMS:**

> xrAPI is a security testing tool intended **EXCLUSIVELY** for authorized security testing. You **MUST** obtain explicit written authorization before scanning any system you do not own. Unauthorized access to computer systems is a **criminal offense** in most jurisdictions.

- ✅ Use only on systems you own or have explicit written permission to test
- ✅ You are solely responsible for ensuring compliance with all applicable laws
- ✅ The authors accept **NO liability** for misuse or damage caused by this tool
- ❌ **NEVER** scan systems without proper authorization

**See [LICENSE](LICENSE) for the complete legal disclaimer and GNU GPL v3.0 terms.**

---

## 📋 Table of Contents

- [Features](#-features)
- [Installation](#-installation)
- [Quick Start](#-quick-start)
- [Backend Setup](#-backend-setup)
- [Usage](#-usage)
- [Web Dashboard](#-web-dashboard)
- [CLI Reference](#-cli-reference)
- [API Documentation](#-api-documentation)
- [Contributing](#-contributing)
- [License](#-license)

---

## ✨ Features

| Feature | Description |
|---------|-------------|
| 🔥 **Async HTTP/2 Scanning** | High-concurrency scanning with `asyncio` and `httpx` |
| 🧠 **Intelligent Clustering** | Groups `/users/1`, `/users/2` → `/users/{id}` automatically |
| 📊 **Response Analysis** | Entropy calculation, structure fingerprinting |
| 🔐 **Auth-Aware Testing** | Compares authenticated vs unauthenticated responses |
| ⚡ **Adaptive Rate Limit** | Automatically adjusts to target responsiveness |
| 🌐 **Web Dashboard** | Beautiful dark-themed UI with D3.js visualization |
| 💾 **Local Storage** | Serverless mode - saves to `~/.xrapi/` |
| 📤 **Multiple Exports** | JSON, CSV, HTML reports, OpenAPI specs |
| 🔍 **Diff & Changelog** | Compare scans over time |

---

## 📦 Installation

### Prerequisites

- **Python 3.11 or higher**
- **pip** (Python package manager)
- **Git** (for cloning)

### Method 1: Install from Source (Recommended)

```bash
# Clone the repository
git clone https://github.com/fiozxr/xrapi.git
cd xrapi

# Create virtual environment (recommended)
python3 -m venv venv

# Activate virtual environment
# On Linux/macOS:
source venv/bin/activate
# On Windows:
venv\Scripts\activate

# Install xrAPI
pip install -e .

# Or with web dashboard support
pip install -e ".[web]"

# Verify installation
xrapi --version
```

### Method 2: Direct pip install (when published)

```bash
pip install xrapi
```

### Method 3: Using the install script

```bash
curl -sSL https://raw.githubusercontent.com/fiozxr/xrapi/main/install.sh | bash
```

---

## 🚀 Quick Start

```bash
# Basic scan (replace with YOUR authorized target)
xrapi scan https://api.example.com

# Scan with web dashboard
xrapi scan https://api.example.com --web

# Launch dashboard separately
xrapi dashboard

# List saved scans
xrapi list

# Export results as HTML
xrapi export <scan-id> -o report.html -f html
```

---

## 🔧 Backend Setup

### Option 1: Serverless Mode (Default)

xrAPI works **without any backend server** by default. All data is stored locally in `~/.xrapi/`:

```
~/.xrapi/
├── scans/          # Scan results (JSON)
├── logs/           # Application logs
├── wordlists/      # Custom wordlists
└── exports/        # Exported reports
```

### Option 2: With FastAPI Backend

For advanced features like multi-user support, database storage, and remote access:

```bash
# Install with web dependencies
pip install -e ".[web]"

# Start the backend server
python -m xrapi.api.server

# Or using uvicorn directly
uvicorn xrapi.api.server:app --host 0.0.0.0 --port 8000 --reload
```

The API will be available at `http://localhost:8000`

### Backend Configuration

Create a `.env` file in the project root:

```env
# Database
DATABASE_URL=sqlite+aiosqlite:///xrapi.db

# Server
XRAPI_HOST=0.0.0.0
XRAPI_PORT=8000

# Logging
LOG_LEVEL=INFO
LOG_FORMAT=json

# Security
SECRET_KEY=your-secret-key-here
```

### Backend API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/health` | GET | Health check |
| `/api/scans` | GET/POST | List/Create scans |
| `/api/scans/{id}` | GET | Get scan details |
| `/api/scans/{id}/clusters` | GET | Get scan clusters |
| `/api/scans/{id}/transactions` | GET | Get HTTP transactions |
| `/api/dashboard/metrics` | GET | Dashboard metrics |
| `/ws` | WebSocket | Real-time updates |

---

## 💻 Usage

### CLI Commands

```
xrapi [COMMAND] [OPTIONS]

Commands:
  scan        Start a new API endpoint discovery scan
  list        List all locally saved scans
  show        Show detailed information about a scan
  export      Export a scan to various formats
  diff        Compare two scans
  dashboard   Launch the web dashboard
  wordlist    Manage custom wordlists
  logs        View application logs
```

### Scan Options

```bash
xrapi scan <TARGET> [OPTIONS]

Options:
  -n, --name TEXT           Scan name for identification
  -w, --wordlist PATH       Wordlist file(s)
  -c, --concurrency INT     Concurrent requests (1-200) [default: 50]
  -r, --rate-limit FLOAT    Requests per second (0=unlimited)
  -t, --timeout INT         Request timeout [default: 30]
  -e, --extensions TEXT     File extensions to try
  -H, --header TEXT         Custom headers (Key:Value)
  --cookie TEXT             Cookie string
  -a, --auth TEXT           Authorization token
  -p, --proxy TEXT          Proxy URL
  --http2 / --no-http2      Enable HTTP/2 [default: enabled]
  -o, --output PATH         Output file path
  -f, --format TEXT         Output format: json, csv, html, openapi
  --hide-codes TEXT         Status codes to hide
  -W, --web                 Launch web dashboard after scan
  -v, --verbose             Verbose output
  --no-save                 Don't save scan locally
```

### Examples

```bash
# Basic scan
xrapi scan https://api.example.com

# Scan with authentication
xrapi scan https://api.example.com -a "Bearer YOUR_TOKEN"

# High concurrency with rate limiting
xrapi scan https://api.example.com -c 100 -r 50

# Scan with custom wordlist and export
xrapi scan https://api.example.com -w wordlist.txt -o results.json

# Generate HTML report
xrapi scan https://api.example.com -o report.html -f html --web

# Compare two scans
xrapi diff scan_20240114 scan_20240115
```

---

## 🌐 Web Dashboard

### Launching

```bash
# Launch standalone dashboard
xrapi dashboard

# On custom port
xrapi dashboard -p 8080

# Load specific scan
xrapi dashboard --scan scan_id

# Don't open browser
xrapi dashboard --no-browser
```

### Dashboard Views

| View | Description |
|------|-------------|
| **Dashboard** | Real-time metrics, API graph, risk summary |
| **New Scan** | Full configuration UI |
| **Results** | Cluster browser, transactions, timeline |
| **Changelog** | Temporal diff, security alerts |

---

## 📁 Project Structure

```
xrapi/
├── backend/
│   └── xrapi/
│       ├── core/
│       │   └── scanner.py          # Async scanning engine
│       ├── api/
│       │   └── server.py           # FastAPI backend (optional)
│       ├── cli/
│       │   ├── standalone.py       # Serverless CLI
│       │   └── web.py              # Dashboard launcher
│       ├── db/
│       │   └── models.py           # Database models
│       └── utils/
│           └── logging.py          # Structured logging
├── frontend/                       # Vanilla HTML/CSS/JS
│   ├── index.html
│   └── static/
│       ├── css/style.css
│       └── js/app.js
├── pyproject.toml                  # Modern Python packaging
├── LICENSE                         # GNU GPL v3.0
├── README.md                       # This file
└── install.sh                      # One-line installer
```

---

## 🔌 API Documentation

### Python API

```python
from xrapi import AsyncScanner, ScanConfig
import asyncio

async def main():
    config = ScanConfig(
        target_url="https://api.example.com",
        concurrency=50,
        rate_limit=100
    )
    
    scanner = AsyncScanner(config)
    results = await scanner.scan()
    
    print(f"Found {results['clusters']} clusters")
    print(f"Discovered {results['discovered_endpoints']} endpoints")

asyncio.run(main())
```

### REST API (when backend is running)

```bash
# Health check
curl http://localhost:8000/api/health

# Create scan
curl -X POST http://localhost:8000/api/scans \
  -H "Content-Type: application/json" \
  -d '{"target_url": "https://api.example.com"}'

# Get scan results
curl http://localhost:8000/api/scans/{scan_id}

# Export as OpenAPI
curl http://localhost:8000/api/scans/{scan_id}/export?format=openapi
```

---

## 🤝 Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Make your changes
4. Run tests (`pytest`)
5. Commit your changes (`git commit -m 'Add amazing feature'`)
6. Push to the branch (`git push origin feature/amazing-feature`)
7. Open a Pull Request

### Development Setup

```bash
git clone https://github.com/fiozxr/xrapi.git
cd xrapi
pip install -e ".[dev,web]"
```

### Code Style

- Follow PEP 8
- Use type hints
- Maximum line length: 100 characters
- Run `black` and `ruff` before committing

---

## 🐛 Troubleshooting

### Common Issues

**Issue**: `xrapi: command not found`

**Solution**: Ensure the virtual environment is activated and xrAPI is installed:
```bash
source venv/bin/activate
pip install -e .
```

**Issue**: `ModuleNotFoundError: No module named 'xrapi'`

**Solution**: Install xrAPI in development mode:
```bash
pip install -e .
```

**Issue**: Web dashboard not loading

**Solution**: Check if the frontend files exist:
```bash
ls frontend/index.html
```

---

## 📄 License

This project is licensed under the **GNU General Public License v3.0** - see the [LICENSE](LICENSE) file for details.

### Third-Party Licenses

- FastAPI (MIT License)
- httpx (BSD License)
- Typer (MIT License)
- Rich (MIT License)

---

## 👤 Author

**fiozxr**

- GitHub: [@fiozxr](https://github.com/fiozxr)
- Repository: [https://github.com/fiozxr/xrapi](https://github.com/fiozxr/xrapi)

---

## 🙏 Acknowledgments

- Built with modern Python async patterns
- Inspired by tools like Gobuster, Dirb, and FFUF
- Thanks to all contributors and the security community

---

<p align="center">
  <sub>Built with ❤️ for the security community</sub><br>
  <sub><strong>Use responsibly. Test ethically. Stay legal.</strong></sub>
</p>
